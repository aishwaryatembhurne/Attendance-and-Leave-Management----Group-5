import React, { useCallback, useState } from "react";
import { Button, Form, Image, Alert } from "react-bootstrap"; // Import Alert component from react-bootstrap
import { AuthenticationAPI } from "../Service/UserApiService";
import { useNavigate } from "react-router-dom";
import "../Pages/css/Login.css";
import logo from "../Assets/logo.png";
import loginman from "../Assets/loginman.png";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faEye, faEyeSlash } from "@fortawesome/free-solid-svg-icons";

const LoginPage = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(""); // New state to hold the error message
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);

  const handleEmailLogin = useCallback(
    (event) => {
      event.preventDefault();

      const loginRequest = {
        email: email,
        password: password,
      };

      AuthenticationAPI.authenticate(loginRequest)
        .then((response) => {
          sessionStorage.setItem("login", true);
          // Login successful
          // Store the token or perform any necessary actions
          navigate("/Dashboard");
        })
        .catch((error) => {
          // Login failed
          console.error(error);
          setError("Invalid email or password. Please try again."); // Set the error message
        });
    },
    [email, password, navigate]
  );

  return (
    <div className="login-page">
      <Image src={logo} className="logo" />
      <h1 className="h1">Attendance and Leave Management System</h1>
      <Image src={loginman} className="loginman" />
      <div className="login-container">
        <div className="login-form">
          <h2 className="login-title">Login</h2>
          {error && <Alert variant="danger">{error}</Alert>}{" "}
          {/* Display the error message */}
          <Form onSubmit={handleEmailLogin} noValidate>
            <Form.Group controlId="formEmail">
              <Form.Label>Email Address:</Form.Label>
              <Form.Control
                type="email"
                name="email"
                value={email}
                onChange={(event) => setEmail(event.target.value)}
              />
            </Form.Group>
            <Form.Group controlId="formPassword">
              <Form.Label>Password:</Form.Label>
              <div className="password-input">
                <Form.Control
                  type={showPassword ? "text" : "password"}
                  name="password"
                  value={password}
                  onChange={(event) => setPassword(event.target.value)}
                />
                <FontAwesomeIcon
                  icon={showPassword ? faEyeSlash : faEye}
                  className="password-icon"
                  onClick={() => setShowPassword(!showPassword)}
                />
              </div>
            </Form.Group>

            <Button
              type="submit"
              variant="primary"
              style={{ marginTop: "10px" }}
            >
              Login
            </Button>
          </Form>
        </div>
      </div>
    </div>
  );
};

export default LoginPage;
