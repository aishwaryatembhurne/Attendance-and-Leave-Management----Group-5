import React from "react";
import NavigationBar from "../Components/NavigationBar";
import Sidebar from "../Components/Sidebar";
import AttendanceCard from "../Components/Attendance/AttendanceCard";
import "./css/Dashboard.css"; // Import the custom CSS file
import LeaveBalanceCard from "../Components/Leave/LeaveBalanceCard";

export default function Dashboard() {
  return (
    <>
      <div>
        <NavigationBar />
        <Sidebar />

        <div className="container">
          <div className="main-content">
            <div className="card-container">
              <AttendanceCard />
              <LeaveBalanceCard />
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
