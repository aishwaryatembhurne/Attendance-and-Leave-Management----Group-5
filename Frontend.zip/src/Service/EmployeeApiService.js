import axios from "axios";
import { Await } from "react-router-dom";

const employeeApi_BASE_URL = "http://localhost:8081";

const employeeApi = axios.create({
  baseURL: employeeApi_BASE_URL,
});

const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Employee employeeApi methods

// Example method to get employee by name
export const getEmployeeByName = (name) => {
  return employeeApi.get(`/employees/byname/${name}`);
};

// Example method to get employee by email
export const getEmployeeByEmail = (email) => {
  return employeeApi.get(`/employees/byemail/${email}`);
};

export const getEmployeesByManagerId = (managerId) => {
  return employeeApi.get(`/employees/manager/${managerId}`, getConfig());
};

export const getEmployeesByStatus = (status) => {
  return employeeApi.get(`/employees/status/${status}`);
};

// Example method to get employee by ID
export const getEmployeeById = (employeeId) => {
  return employeeApi.get(`/employees/${employeeId}`, getConfig());
};

export const getAllEmployee = () => {
  return employeeApi.get(`/employees/getAllEmployees`, getConfig());
};

// Example method to update an employee
export const updateEmployee = (employeeDTO) => {
  return employeeApi.put("/employees", employeeDTO, getConfig());
};

export const updateEmployeeStatus = (id) => {
  try {
    const response = employeeApi.put(
      `/employees/${id}/status`,
      null,
      getConfig()
    );
    return response;
  } catch (error) {
    throw error;
  }
};

//update method to update employee
export const updateEmployees = (employee) => {
  return employeeApi.put("/employees/update", employee, getConfig());
};

// Example method to save a new employee
export const saveEmployee = (employeeDTO) => {
  return employeeApi.post("/employees", employeeDTO, getConfig());
};

// Example method to upload an employee file
export const saveEmployeeFromExcel = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return employeeApi.post("/employees/upload", formData, getConfig());
};

export const exportEmployeesToPDF = (managerId) => {
  return employeeApi.get(`/employees/manager/${managerId}/pdf`, {
    responseType: "blob",
    ...getConfig(),
  });
};
// Example method to download all employees
export const downloadAllEmployees = () => {
  return employeeApi.get("/employees/download", {
    responseType: "blob",
    ...getConfig(),
  });
};

// Example method to download employees under a manager
export const downloadEmployeesByManager = (managerId) => {
  return employeeApi.get(
    `/employees/download/${managerId}`,
    {
      responseType: "blob",
    },
    getConfig()
  );
};

// Example method to delete an employee
export const deleteEmployee = (employeeId) => {
  return employeeApi.delete(`/employees/${employeeId}`);
};

export default employeeApi;
