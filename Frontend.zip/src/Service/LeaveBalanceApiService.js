import axios from "axios";

const leaveBalanceApi_BASE_URL = "http://localhost:8081";

const leaveBalanceApi = axios.create({
  baseURL: leaveBalanceApi_BASE_URL,
});

// Set the token in the request headers
// leaveBalanceApi.interceptors.request.use(
//   (config) => {
//     const token = sessionStorage.getItem("token"); // Retrieve the token from storage
//     if (token) {
//       config.headers.Authorization = "Bearer " + token;
//     }
//     return config;
//   },
//   (error) => {
//     return Promise.reject(error);
//   }
// );
// token = sessionStorage.getItem("token");
const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Leave Balance API methods

export const getLeaveBalancesByEmployeeId = (employeeId) => {
  return leaveBalanceApi.get(`/leavebalances/${employeeId}`, getConfig());
};

export const getLeaveBalanceByEmployeeAndCategory = (
  employeeId,
  categoryId
) => {
  return leaveBalanceApi.get(
    `/leavebalances/${employeeId}/${categoryId}`,
    getConfig()
  );
};

export const updateLeaveBalance = (employeeId, categoryId, balance) => {
  return leaveBalanceApi.put(
    `/leavebalances/${employeeId}/${categoryId}?balance=${balance}`,
    null,
    getConfig()
  );
};

export const createLeaveBalance = (employeeId, categoryId, balance) => {
  return leaveBalanceApi.post(
    `/leavebalances/${employeeId}/${categoryId}?balance=${balance}`,
    null,
    getConfig()
  );
};

export default leaveBalanceApi;
