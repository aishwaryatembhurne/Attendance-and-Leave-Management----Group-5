import axios from "axios";

const rosterApi_BASE_URL = "http://localhost:8081";

const rosterApi = axios.create({
  baseURL: rosterApi_BASE_URL,
});

const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Roster API methods

export const getEmployeeRoster = (employeeId, startDate, endDate) => {
  return rosterApi.get(`/rosters/${employeeId}`, {
    ...getConfig(),
    params: {
      startDate,
      endDate,
    },
  });
};

export const getEmployeeRosterByType = (employeeId, rosterType) => {
  return rosterApi.get(`/rosters/${employeeId}/${rosterType}`, getConfig());
};

export const updateRoster = (rosterDto) => {
  return rosterApi.put("/rosters", rosterDto, getConfig());
};

export const getTodayRoster = (employeeId) => {
  return rosterApi.put(`/rosters/today/${employeeId}`, getConfig());
};

export const createRoster = (rosterDto) => {
  return rosterApi.post("/rosters", rosterDto, getConfig());
};

export const deleteRoster = (rosterId) => {
  return rosterApi.delete(`/rosters/${rosterId}`, getConfig());
};

export const uploadFile = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return rosterApi.post("/rosters/upload", formData, getConfig());
};

export const downloadFile = (employeeId) => {
  return rosterApi.get(`/rosters/download?id=${employeeId}`, {
    ...getConfig(),
    responseType: "blob", // Set the response type to blob
  });
};

export default rosterApi;
