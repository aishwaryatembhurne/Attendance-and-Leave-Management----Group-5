import axios from "axios";

const leaveApi_BASE_URL = "http://localhost:8081";

const leaveApi = axios.create({
  baseURL: leaveApi_BASE_URL,
});

const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Leave leaveApi methods

export const getEmployeeLeaves = (employeeId, startDate, endDate) => {
  return leaveApi.get(`/leaves/${employeeId}`, {
    params: {
      startDate: startDate,
      endDate: endDate,
    },
    ...getConfig(),
  });
};

export const getLeavesByStatus = (status) => {
  return leaveApi.get(`/leaves/status/${status}`, getConfig());
};

export const deleteLeave = (leaveId) => {
  return leaveApi.delete(`/leaves/${leaveId}`, getConfig());
};

export const getAllLeavesByEmployeeId = (employeeId) => {
  return leaveApi.get(`/leaves/employee/${employeeId}`, getConfig());
};

export const applyLeave = (leaveDTO) => {
  return leaveApi.post("/leaves/apply", leaveDTO, getConfig());
};

export const updateLeave = async (leaveId, status) => {
  try {
    const response = await leaveApi.put(`/leaves/update`, null, {
      params: {
        leaveId: leaveId,
        status: status,
      },
      ...getConfig(),
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};
export const getAllLeavesByManagerId = (managerId) => {
  return leaveApi.get(`/leaves/manager/${managerId}`, getConfig());
};

export default leaveApi;
