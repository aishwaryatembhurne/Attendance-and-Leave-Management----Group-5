import axios from "axios";

const leaveCategoryApi_BASE_URL = "http://localhost:8081";

const leaveCategoryApi = axios.create({
  baseURL: leaveCategoryApi_BASE_URL,
});

const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Leave Category API methods

export const getAllLeaveCategories = () => {
  return leaveCategoryApi.get("/api/leave-categories", getConfig());
};

export const getLeaveCategoryById = (leaveCategoryId) => {
  return leaveCategoryApi.get(
    `/api/leave-categories/${leaveCategoryId}`,
    getConfig()
  );
};

export const createLeaveCategory = (leaveCategory) => {
  return leaveCategoryApi.post(
    "/api/leave-categories",
    leaveCategory,
    getConfig()
  );
};

export const updateLeaveCategory = (leaveCategoryId, leaveCategory) => {
  return leaveCategoryApi.put(
    `/api/leave-categories/${leaveCategoryId}`,
    leaveCategory,
    getConfig()
  );
};

export const deleteLeaveCategory = (leaveCategoryId) => {
  return leaveCategoryApi.delete(
    `/api/leave-categories/${leaveCategoryId}`,
    getConfig()
  );
};

export default leaveCategoryApi;
