import axios from "axios";

const departmentApi_BASE_URL = "http://localhost:8081";

const departmentApi = axios.create({
  baseURL: departmentApi_BASE_URL,
});

// Set the token in the request headers
// departmentApi.interceptors.request.use(
//   (config) => {
//     const token = sessionStorage.getItem("token"); // Retrieve the token from storage
//     if (token) {
//       config.headers.Authorization = "Bearer " + token;
//     }
//     return config;
//   },
//   (error) => {
//     return Promise.reject(error);
//   }
// );
// token = sessionStorage.getItem("token");
const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Department API methods

export const createDepartment = (department) => {
  return departmentApi.post("/departments", department, getConfig());
};

export const getDepartmentById = (departmentId) => {
  return departmentApi.get(`/departments/${departmentId}`, getConfig());
};

export const getAllDepartments = () => {
  return departmentApi.get("/departments", getConfig());
};

export const updateDepartment = (departmentId, department) => {
  return departmentApi.put(
    `/departments/${departmentId}`,
    department,
    getConfig()
  );
};

export const deleteDepartment = (departmentId) => {
  return departmentApi.delete(`/departments/${departmentId}`, getConfig());
};

export default departmentApi;
