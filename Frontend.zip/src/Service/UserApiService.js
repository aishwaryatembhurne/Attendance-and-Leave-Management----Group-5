import axios from "axios";

const baseUserUrl = "http://localhost:8081/api/v1/auth";

export const AuthenticationAPI = {
  register: async (request) => {
    try {
      const response = await axios.post(`${baseUserUrl}/register`, request);
      return response.data;
    } catch (error) {
      throw new Error(error.response.data.message);
    }
  },

  authenticate: async (request) => {
    try {
      const response = await axios.post(`${baseUserUrl}/authenticate`, request);
      const token = "Bearer " + response.data.access_token;
      const employeeId = response.data.employeeId;
      const role = response.data.role;
      sessionStorage.setItem("token", token);
      sessionStorage.setItem("employeeId", employeeId);
      sessionStorage.setItem("role", role);
      return response;
    } catch (error) {
      // alert(
      //   "There was an error while logging in. Please verify your email and password."
      // );
      throw new Error(error.response);
    }
  },

  updatePassword: async (updatePasswordRequest) => {
    try {
      const response = await axios.post(
        `${baseUserUrl}/updatePassword`,
        updatePasswordRequest
      );
      return response.data;
    } catch (error) {
      throw new Error(error.response.data.message);
    }
  },
};
