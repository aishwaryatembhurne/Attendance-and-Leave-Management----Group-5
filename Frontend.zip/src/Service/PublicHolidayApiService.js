import axios from "axios";

const publicHolidayApi_BASE_URL = "http://localhost:8081";

const publicHolidayApi = axios.create({
  baseURL: publicHolidayApi_BASE_URL,
});

const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

// Public Holiday API methods

export const uploadFile = (file) => {
  const formData = new FormData();
  formData.append("file", file);
  return publicHolidayApi.post("/publicholidays/upload", formData, getConfig());
};

export const downloadFile = () => {
  return publicHolidayApi.get("/publicholidays/download", {
    ...getConfig(),
    responseType: "blob", // Set the response type to blob
  });
};

export const getAllPublicHolidays = () => {
  return publicHolidayApi.get("/publicholidays", getConfig());
};

export const getPublicHolidayById = (publicHolidayId) => {
  return publicHolidayApi.get(
    `/publicholidays/${publicHolidayId}`,
    getConfig()
  );
};

export const createPublicHoliday = (publicHolidayDto) => {
  return publicHolidayApi.post(
    "/publicholidays",
    publicHolidayDto,
    getConfig()
  );
};

export const updatePublicHoliday = (publicHolidayId, publicHolidayDto) => {
  return publicHolidayApi.put(
    `/publicholidays/${publicHolidayId}`,
    publicHolidayDto,
    getConfig()
  );
};

export const deletePublicHoliday = (publicHolidayId) => {
  return publicHolidayApi.delete(
    `/publicholidays/${publicHolidayId}`,
    getConfig()
  );
};

export default publicHolidayApi;
