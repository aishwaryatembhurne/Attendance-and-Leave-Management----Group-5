import axios from "axios";

const attendanceApi_BASE_URL = "http://localhost:8081";

const attendanceApi = axios.create({
  baseURL: attendanceApi_BASE_URL,
});

const getConfig = () => {
  const config = {
    headers: {
      Authorization: sessionStorage.getItem("token"),
    },
  };
  return config;
};

export const getEmployeeAttendance = async (employeeId, startDate, endDate) => {
  try {
    const response = await attendanceApi.get(`/attendances/${employeeId}`, {
      params: {
        startDate: startDate,
        endDate: endDate,
      },
      ...getConfig(),
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getAttendanceByEmployeeIdForToday = async (employeeId) => {
  try {
    const response = await attendanceApi.get(
      `/attendances/todayAttendance/${employeeId}`,
      getConfig()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const getAttendanceByStatus = async (status) => {
  try {
    const response = await attendanceApi.get(
      `/attendances/status/${status}`,
      getConfig()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const updateAttendance = async (attendanceId, status) => {
  try {
    const response = await attendanceApi.put(`/attendances`, null, {
      params: {
        attendanceId: attendanceId,
        status: status,
      },
      ...getConfig(),
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const createAttendance = async (attendanceDTO) => {
  try {
    const response = await attendanceApi.post(
      "/attendances",
      attendanceDTO,
      getConfig()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const deleteAttendance = async (attendanceId) => {
  try {
    const response = await attendanceApi.delete(
      `/attendances/${attendanceId}`,
      getConfig()
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const exportAttendanceToPDF = async (employeeId, startDate, endDate) => {
  try {
    const response = await attendanceApi.get(
      `/attendances/${employeeId}/export`,
      {
        params: {
          startDate: startDate,
          endDate: endDate,
        },
        ...getConfig(),
        responseType: "blob",
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const exportAttendancesToPDF = async (managerId, startDate, endDate) => {
  try {
    const response = await attendanceApi.get(
      `/attendances/${managerId}/employees/export`,
      {
        params: {
          startDate: startDate,
          endDate: endDate,
        },
        ...getConfig(),
        responseType: "blob",
      }
    );
    return response.data;
  } catch (error) {
    throw error;
  }
};

export const exportAllAttendanceToPDF = async (startDate, endDate) => {
  try {
    const response = await attendanceApi.get(`/attendances/export`, {
      params: {
        startDate: startDate,
        endDate: endDate,
      },
      ...getConfig(),
      responseType: "blob",
    });
    return response.data;
  } catch (error) {
    throw error;
  }
};

const attendanceApiService = {
  getEmployeeAttendance,
  getAttendanceByEmployeeIdForToday,
  getAttendanceByStatus,
  updateAttendance,
  createAttendance,
  deleteAttendance,
  exportAttendanceToPDF,
  exportAttendancesToPDF,
};

export default attendanceApiService;
