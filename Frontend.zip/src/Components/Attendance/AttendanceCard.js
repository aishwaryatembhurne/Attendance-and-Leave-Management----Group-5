import React, { useEffect, useState } from "react";
import "./AttendanceCard.css";
import {
  getAttendanceByEmployeeIdForToday,
  updateAttendance,
} from "../../Service/AttendanceApiService";
import { getTodayRoster } from "../../Service/RosterApiService";

const AttendanceCard = () => {
  const [shouldRenderCard, setShouldRenderCard] = useState(false);
  const [isAttendanceMarked, setIsAttendanceMarked] = useState(false);
  const [roster, setRoster] = useState("updating...");
  const employeeId = sessionStorage.getItem("employeeId");
  const [attendance, setAttendance] = useState();
  const [message, setMessage] = useState(null); // State for displaying messages

  useEffect(() => {
    const checkAttendance = async () => {
      try {
        const hasMarkedAttendance = await getAttendanceByEmployeeIdForToday(
          employeeId
        );
        console.log("Attendance data: ", hasMarkedAttendance);
        setAttendance(hasMarkedAttendance);
        // Update the state based on the condition
        if (hasMarkedAttendance && hasMarkedAttendance.attendanceStatus) {
          setShouldRenderCard(
            hasMarkedAttendance.attendanceStatus === "Absent"
          );
        } else {
          // setShouldRenderCard(true);
        }
      } catch (error) {
        // Handle errors
        console.error("Failed to check attendance", error);
      }
    };

    checkAttendance();
  }, []);

  const handleAttendanceMark = () => {
    if (attendance && attendance.workMode) {
      const status = "Present";

      // Call the updateAttendance method to mark the attendance
      updateAttendance(attendance.attendanceId, status)
        .then((response) => {
          // Handle the response or perform any additional actions
          setMessage("Attendance marked successfully");
          // Update the state to indicate that the attendance is marked
          setIsAttendanceMarked(true);
        })
        .catch((error) => {
          // Handle the error or display an error message
          setMessage("Failed to mark attendance");
          console.error("Failed to mark attendance", error);
        });
    } else {
      // Handle the case when workMode is missing or undefined
      setMessage("Invalid work mode. Cannot mark attendance.");
    }
  };

  const currentDate = new Date();
  const todayDate = currentDate.toDateString();

  if (!shouldRenderCard || isAttendanceMarked) {
    return null; // Don't render the card if the condition is false or if attendance is already marked
  }

  return (
    <div className="card">
      <div className="card-header">
        <h5 className="card-title">Today's Attendance</h5>
        <p className="card-subtitle">{todayDate}</p>
      </div>
      <div className="card-body">
        <p>Roster Type for Today: {attendance.workMode}</p>
      </div>
      <div className="card-footer">
        <button className="btn btn-primary" onClick={handleAttendanceMark}>
          Mark Your Attendance
        </button>
      </div>
      {message && <p className="message">{message}</p>}{" "}
      {/* Render the message */}
    </div>
  );
};

export default AttendanceCard;
