import { useState, useEffect } from "react";
import { NavLink } from "react-router-dom";

import "./Employee.css";
import {
  downloadEmployeesByManager,
  exportEmployeesToPDF,
  getEmployeesByManagerId,
  updateEmployee,
  updateEmployeeStatus,
  updateEmployees,
} from "../../Service/EmployeeApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import { OverlayTrigger, Tooltip, Pagination } from "react-bootstrap";
import {
  RiFileList2Line,
  RiCalendarEventLine,
  RiEdit2Line,
} from "react-icons/ri";
import { exportAttendancesToPDF } from "../../Service/AttendanceApiService";

const Message = ({ message, onClose, onCancel }) => {
  return (
    <div className="message-box">
      <p>{message}</p>
      <div className="message-buttons">
        <button onClick={onClose}>OK</button>
        <button onClick={onCancel}>Cancel</button>
      </div>
    </div>
  );
};

function EmployeeList() {
  const [searchQuery, setSearchQuery] = useState("");
  const [filteredEmployees, setFilteredEmployees] = useState([]);
  const employeeId = sessionStorage.getItem("employeeId");
  const [employees, setEmployees] = useState([]);
  const [currentPage, setCurrentPage] = useState(1);
  const [showInputFields, setShowInputFields] = useState(false);
  const [startDate, setStartDate] = useState("");
  const [employeesPerPage] = useState(8);
  const role = sessionStorage.getItem("role");
  const [endDate, setEndDate] = useState("");
  const [showMessage, setShowMessage] = useState(false);
  const [employeeToDisable, setEmployeeToDisable] = useState(null);

  useEffect(() => {
    getAllEmployees();
  }, []);

  useEffect(() => {
    setFilteredEmployees(filterEmployees(searchQuery));
  }, [searchQuery, employees]);

  async function getAllEmployees() {
    try {
      const managerId = sessionStorage.getItem("employeeId");
      const response = await getEmployeesByManagerId(managerId);
      setEmployees(response.data);
      setFilteredEmployees(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  function filterEmployees(query) {
    const normalizedQuery = query.toLowerCase();
    const filtered = employees.filter((employee) => {
      const fullName =
        `${employee.firstName} ${employee.lastName} ${employee.emailId} ${employee.department.departmentName} ${employee.employeeType}`.toLowerCase();
      return fullName.includes(normalizedQuery);
    });
    return filtered;
  }

  const handleDownloadClick = () => {
    setShowInputFields((prevShowInputFields) => !prevShowInputFields);
    setStartDate(""); // Reset start date when toggling input fields
    setEndDate(""); // Reset end date when toggling input fields
  };

  const handleDownload = async () => {
    try {
      if (startDate && endDate) {
        const attendancePdf = await exportAttendancesToPDF(
          employeeId,
          startDate,
          endDate
        );
        const blob = new Blob([attendancePdf], { type: "application/pdf" });
        const url = URL.createObjectURL(blob);
        const link = document.createElement("a");
        link.href = url;
        link.download = "attendance.pdf";
        link.click();
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error(error);
    }
  };

  const handleEmployeeDownload = async () => {
    try {
      const response = await exportEmployeesToPDF(employeeId);
      const blob = new Blob([response.data], { type: "application/pdf" });
      const url = URL.createObjectURL(blob);
      const link = document.createElement("a");
      link.href = url;
      link.download = "employee_list.pdf";
      link.click();
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error(error);
    }
  };

  async function disableEmployee(employeeId) {
    const confirmed = window.confirm(
      "Are you sure you want to disable the employee?"
    );
    if (confirmed) {
      try {
        await updateEmployeeStatus(employeeId);
        window.location.reload();
      } catch (error) {
        console.log(error);
      }
    }
  }

  async function handleDisableEmployee() {}

  // Pagination logic
  const indexOfLastEmployee = currentPage * employeesPerPage;
  const indexOfFirstEmployee = indexOfLastEmployee - employeesPerPage;
  const currentEmployees = filteredEmployees.slice(
    indexOfFirstEmployee,
    indexOfLastEmployee
  );

  const paginate = (pageNumber) => setCurrentPage(pageNumber);

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div
        className="displayHeadingBox"
        style={{ width: "270px", background: "transparent", height: "75px" }}
      >
        <h1 style={{ width: "250px", fontSize: "35px" }}>Employee List</h1>

        <input
          className="searchbar"
          type="text"
          placeholder="Search "
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>
      <div>
        <div className="employeedetails-export-button-container">
          <button onClick={handleDownloadClick} className="export-button">
            Download Attendance
          </button>
        </div>

        {showInputFields && (
          <div className="input-fields-container">
            <div className="input-group">
              <div className="start-date-container">
                <label htmlFor="startDate" className="start-date-label">
                  Start Date:
                </label>
                <input
                  type="date"
                  id="startDate"
                  className="start-date-field"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                />
              </div>
            </div>
            <div className="input-group">
              <div className="end-date-container">
                <label htmlFor="endDate" className="end-date-label">
                  End Date:
                </label>
                <input
                  type="date"
                  id="endDate"
                  className="end-date-field"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                />
              </div>
            </div>

            <div className="download-button-container">
              <button onClick={handleDownload} className="export-button">
                Download
              </button>
            </div>
          </div>
        )}
      </div>

      <div className="employeedetails-export-button-container2">
        <button onClick={handleEmployeeDownload} className="export-button">
          Download Employees
        </button>
      </div>

      <div style={{ marginLeft: "209px" }} className="container">
        <div className="tableBox">
          <table className="table table-striped">
            <thead>
              <tr>
                <th>ID</th>
                <th>Name</th>
                <th>Email</th>
                <th>Department</th>
                <th>Employee Type</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {currentEmployees.map((employee) => (
                <tr key={employee.id}>
                  <td>{employee.id}</td>
                  <td>
                    {employee.firstName} {employee.lastName}
                  </td>
                  <td>{employee.emailId}</td>
                  <td>{employee.department.departmentName}</td>
                  <td>{employee.employeeType}</td>
                  {role === "HR" || role === "ADMIN" ? (
                    <td>
                      <button
                        className={`btn btn-${
                          employee.status === "Active" ? "success" : "danger"
                        }`}
                        onClick={() => disableEmployee(employee.id)}
                      >
                        {employee.status === "Active" ? "Active" : "Inactive"}
                      </button>
                    </td>
                  ) : (
                    <td>
                      <button
                        className={`btn btn-${
                          employee.status === "Active" ? "success" : "danger"
                        }`}
                      >
                        {employee.status === "Active" ? "Active" : "Inactive"}
                      </button>
                    </td>
                  )}
                  <td>
                    <OverlayTrigger
                      placement="top"
                      overlay={<Tooltip>Attendance History</Tooltip>}
                    >
                      <NavLink
                        exact
                        to={`/AdminDashboard/Employee/Attendance/${employee.id}`}
                      >
                        <RiCalendarEventLine className="icon icon-margin" />
                      </NavLink>
                    </OverlayTrigger>

                    <OverlayTrigger
                      placement="top"
                      overlay={<Tooltip>Leave History</Tooltip>}
                    >
                      <NavLink exact to={`/employee-leaves/${employee.id}`}>
                        <RiFileList2Line className="icon icon-margin" />
                      </NavLink>
                    </OverlayTrigger>

                    {role === "ADMIN" || role === "HR" ? (
                      <OverlayTrigger
                        placement="top"
                        overlay={<Tooltip>Edit Employee</Tooltip>}
                      >
                        <NavLink
                          exact
                          to={`/AdminDashboard/Employee/Edit/${employee.id}`}
                        >
                          <RiEdit2Line className="icon icon-margin" />
                        </NavLink>
                      </OverlayTrigger>
                    ) : null}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      <div className="go-back-button">
        <NavLink exact to="/Dashboard">
          <button className="btn btn-primary">Go Back</button>
        </NavLink>
      </div>

      <div className="pagination-container">
        <Pagination>
          <Pagination.Prev
            onClick={() => paginate(currentPage - 1)}
            disabled={currentPage === 1}
          />
          {Array(Math.ceil(filteredEmployees.length / employeesPerPage))
            .fill()
            .map((_, index) => (
              <Pagination.Item
                key={index + 1}
                active={index + 1 === currentPage}
                onClick={() => paginate(index + 1)}
              >
                {index + 1}
              </Pagination.Item>
            ))}
          <Pagination.Next
            onClick={() => paginate(currentPage + 1)}
            disabled={
              currentPage ===
              Math.ceil(filteredEmployees.length / employeesPerPage)
            }
          />
        </Pagination>
      </div>
      {/* {showMessage && (
        <Message
          message="Are you sure you want to disable the employee?"
          onClose={() => handleDisableEmployee()}
          onCancel={() => setShowMessage(false)}
        />
      )} */}
    </>
  );
}

export default EmployeeList;
