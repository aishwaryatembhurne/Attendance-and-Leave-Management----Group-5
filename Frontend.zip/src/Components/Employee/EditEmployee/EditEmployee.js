import React, { useState, useEffect } from "react";
import { Button } from "react-bootstrap";
import {
  getEmployeeById,
  updateEmployees,
} from "../../../Service/EmployeeApiService";

import "../EmployeeForm.css";
import NavigationBar from "../../NavigationBar";
import Sidebar from "../../Sidebar";
import { useNavigate, useParams } from "react-router-dom";

const EditEmployee = () => {
  const navigate = useNavigate();
  const { employeeId } = useParams();
  const [employee, setEmployee] = useState({
    id: employeeId,
    firstName: "",
    lastName: "",
    emailId: "",
    dateOfBirth: "",
    contactNumber: "",
    emergencyContactNumber: "",
    gender: "",
    country: "",
    maritalStatus: "",
    permanentAddress: "",
    dateOfJoining: "",
    designation: "",
    jobTitle: "",
    status: "Active",
    employeeType: "",
    department: {
      departmentId: "",
      departmentName: "",
    },
    managerId: "",
  });

  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [errors, setErrors] = useState({});

  useEffect(() => {
    getEmployeeDetails();
  }, []);

  const getEmployeeDetails = async () => {
    try {
      const response = await getEmployeeById(employeeId);
      setEmployee(response.data);
      console.log("Employee Data fetched: ", response.data);
    } catch (error) {
      console.log("Exception occurred");
      console.log(error);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;

    if (name === "manager") {
      const [managerId] = value;
      setEmployee((prevEmployee) => ({
        ...prevEmployee,
        managerId: managerId,
      }));
    } else {
      setEmployee((prevEmployee) => ({ ...prevEmployee, [name]: value }));

      if (name === "contactNumber" || name === "emergencyContactNumber") {
        const isValidNumber = /^\d{10}$/.test(value);
        if (!isValidNumber) {
          setErrors((prevErrors) => ({
            ...prevErrors,
            [name]: "Please enter a 10-digit number",
          }));
          setTimeout(() => {
            setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
          }, 3000);
        } else {
          setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
        }
      }
    }
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    updateEmployees(employee)
      .then((response) => {
        setSuccessMessage("Employee updated successfully!");
        console.log("Employee After updated: ", response);
      })
      .catch((error) => {
        setErrorMessage("No fields changed (make sure manager is selected)");
        console.error(error.message);
      });

    setTimeout(() => {
      setErrorMessage("");
      setSuccessMessage("");
    }, 3000);
  };

  const handleGoBack = () => {
    navigate("/employee-list");
  };

  const currentDate = new Date();
  const maxDateOfBirth = new Date(
    currentDate.getFullYear() - 18,
    currentDate.getMonth(),
    currentDate.getDate()
  )
    .toISOString()
    .split("T")[0];

  const eighteenYearsAgo = new Date(
    currentDate.getFullYear() - 18,
    currentDate.getMonth(),
    currentDate.getDate()
  );
  const minDateOfBirth = new Date(
    eighteenYearsAgo.getFullYear() - 100,
    eighteenYearsAgo.getMonth(),
    eighteenYearsAgo.getDate()
  )
    .toISOString()
    .split("T")[0];

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div className="add-employee-page">
        <div className="add-employee-container">
          <div className="add-employee-form">
            <h4
              style={{
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "2em",
              }}
            >
              <br />
              Edit Employee
            </h4>
            <br />
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group name-group">
                <div className="form-group">
                  <label>
                    First Name: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    className="form-control"
                    value={employee.firstName}
                    onChange={handleChange}
                    required
                    readOnly
                  />
                </div>
                <div className="form-group">
                  <label>
                    Last Name: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="lastName"
                    className="form-control"
                    value={employee.lastName}
                    onChange={handleChange}
                    readOnly
                  />
                </div>
              </div>

              <div className="form-group email-dob-group">
                <div className="form-group">
                  <label>
                    Email: <span className="required">*</span>
                  </label>
                  <input
                    type="email"
                    name="emailId"
                    className="form-control"
                    value={employee.emailId}
                    onChange={handleChange}
                    required
                    readOnly
                  />
                </div>
                <div className="form-group">
                  <label>
                    Date of Birth: <span className="required">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfBirth"
                    className="form-control"
                    value={employee.dateOfBirth}
                    onChange={handleChange}
                    max={maxDateOfBirth}
                    min={minDateOfBirth}
                    required
                    readOnly
                  />
                </div>
              </div>

              <div className="form-group contact-group">
                <div className="form-group">
                  <label>
                    Contact Number: <span className="required">*</span>
                  </label>
                  <div className="input-container">
                    <input
                      type="text"
                      name="contactNumber"
                      className="form-control"
                      value={employee.contactNumber}
                      onChange={handleChange}
                      required
                    />
                    {errors.contactNumber && (
                      <div className="employeeform-error-message">
                        {errors.contactNumber}
                      </div>
                    )}
                  </div>
                </div>
                <div className="form-group">
                  <label>
                    Emergency Contact Number:{" "}
                    <span className="required">*</span>
                  </label>
                  <div className="input-container">
                    <input
                      type="text"
                      name="emergencyContactNumber"
                      className="form-control"
                      value={employee.emergencyContactNumber}
                      onChange={handleChange}
                    />
                    {errors.emergencyContactNumber && (
                      <div className="employeeform-error-message">
                        {errors.emergencyContactNumber}
                      </div>
                    )}
                  </div>
                </div>
              </div>

              <div className="form-group gender-country-group">
                <div className="form-group">
                  <label>
                    Gender: <span className="required">*</span>
                  </label>
                  <div className="input-container">
                    <input
                      type="text"
                      name="contactNumber"
                      className="form-control"
                      value={employee.gender}
                      onChange={handleChange}
                      required
                      readOnly
                    />
                  </div>
                </div>
                <div className="form-group">
                  <label>
                    Country: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="country"
                    className="form-control"
                    value={employee.country}
                    onChange={handleChange}
                    required
                    readOnly
                  />
                </div>
              </div>

              <div className="form-group marital-address-group">
                <div className="form-group">
                  <label>
                    Marital Status: <span className="required">*</span>
                  </label>
                  <select
                    name="maritalStatus"
                    className="form-control"
                    value={employee.maritalStatus}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Marital Status</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                  </select>
                </div>
                <div className="form-group">
                  <label>
                    Permanent Address: <span className="required">*</span>
                  </label>
                  <textarea
                    name="permanentAddress"
                    className="form-control"
                    value={employee.permanentAddress}
                    onChange={handleChange}
                    required
                  ></textarea>
                </div>
              </div>

              <div className="form-group joining-designation-group">
                <div className="form-group">
                  <label>
                    Date of Joining: <span className="required">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfJoining"
                    className="form-control"
                    value={employee.dateOfJoining}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>
                    Designation: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="designation"
                    className="form-control"
                    value={employee.designation}
                    onChange={handleChange}
                    required
                  />
                </div>
              </div>

              <div className="form-group title-status-group">
                <div className="form-group">
                  <label>
                    Job Title: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="jobTitle"
                    className="form-control"
                    value={employee.jobTitle}
                    onChange={handleChange}
                    required
                  />
                </div>
                <div className="form-group">
                  <label>
                    Employee Type: <span className="required">*</span>
                  </label>
                  <select
                    name="employeeType"
                    className="form-control"
                    value={employee.employeeType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Employee Type</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="Virtual">Virtual</option>
                  </select>
                </div>
              </div>

              <Button
                type="submit"
                onClick={handleSubmit}
                className="btn-primary"
              >
                Update Employee
              </Button>

              <Button onClick={handleGoBack} className="btn-secondary">
                Go Back
              </Button>
              {errorMessage && (
                <div className="employeeform-employeeform-error-message">
                  {errorMessage}
                </div>
              )}
              {successMessage && (
                <div className="employeeform-success-message">
                  {successMessage}
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default EditEmployee;
