import React, { useState, useEffect, useRef } from "react";
import { Button, NavLink } from "react-bootstrap";
import {
  getAllEmployee,
  saveEmployee,
  saveEmployeeFromExcel,
} from "../../Service/EmployeeApiService";
import { getAllDepartments } from "../../Service/DepartmentApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import "./EmployeeForm.css";
import axios from "axios";
import { useNavigate } from "react-router-dom";

const AddEmployee = () => {
  const [employee, setEmployee] = useState({
    // Employee fields
    firstName: "",
    lastName: "",
    emailId: "",
    dateOfBirth: "",
    contactNumber: "",
    emergencyContactNumber: "",
    gender: "",
    country: "",
    maritalStatus: "",
    permanentAddress: "",
    dateOfJoining: "",
    designation: "",
    jobTitle: "",
    status: "Active",
    employeeType: "",
    managerId: "",
    departmentId: "",
  });

  const [departments, setDepartments] = useState([]);
  const [employees, setEmployees] = useState([]);
  const fileInputRef = useRef(null);
  const [countries, setCountries] = useState([]);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [errors, setErrors] = useState({});
  const navigate = useNavigate();

  useEffect(() => {
    fetchDepartments();
    fetchEmployees();
    fetchCountries();
  }, []);

  const fetchDepartments = async () => {
    try {
      const response = await getAllDepartments();
      setDepartments(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchEmployees = async () => {
    try {
      const response = await getAllEmployee();
      console.log("All employee Data", response.data);
      setEmployees(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchCountries = async () => {
    try {
      const response = await axios.get("https://restcountries.com/v2/all");
      const countryNames = response.data.map((country) => country.name);
      setCountries(countryNames);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;

    if (name === "firstName" || name === "lastName" || name === "designation") {
      const onlyTextRegex = /^[a-zA-Z\s]*$/;
      if (!onlyTextRegex.test(value)) {
        setErrors((prevErrors) => ({
          ...prevErrors,
          [name]: "Only text values are allowed.",
        }));

        // Clear the error message after 3 seconds
        setTimeout(() => {
          setErrors((prevErrors) => ({
            ...prevErrors,
            [name]: "",
          }));
        }, 3000);
      } else {
        setErrors((prevErrors) => ({
          ...prevErrors,
          [name]: "",
        }));
        setEmployee((prevEmployee) => ({
          ...prevEmployee,
          [name]: value,
        }));
      }
    } else {
      setErrors((prevErrors) => ({
        ...prevErrors,
        [name]: "",
      }));
      setEmployee((prevEmployee) => ({
        ...prevEmployee,
        [name]: value,
      }));
    }
  };

  const handleGoBack = () => {
    navigate("/Dashboard");
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (isFormValid()) {
      saveEmployee(employee)
        .then((response) => {
          setSuccessMessage("Employee added successfully!");
          console.log(response);

          // Reset the form fields
          setEmployee({
            firstName: "",
            lastName: "",
            emailId: "",
            dateOfBirth: "",
            contactNumber: "",
            emergencyContactNumber: "",
            gender: "",
            country: "",
            maritalStatus: "",
            permanentAddress: "",
            dateOfJoining: "",
            designation: "",
            jobTitle: "",
            status: "",
            employeeType: "",
            managerId: "",
            departmentId: "",
          });
          setErrors({});
          setTimeout(() => {
            setSuccessMessage("");
          }, 3000);
        })
        .catch((error) => {
          console.error(error.message);
          // Handle the error or display an error message
        });
    } else {
      // Form is not valid, set error messages
      setErrors({
        firstName: !employee.firstName ? "First name is required" : "",
        emailId: !employee.emailId
          ? "Email is required"
          : !isValidEmail(employee.emailId)
          ? "Invalid email format"
          : "",
        dateOfBirth: !employee.dateOfBirth ? "Date of birth is required" : "",
        contactNumber:
          !employee.contactNumber || employee.contactNumber.length !== 10
            ? "Contact number is required and must be exactly 10 digits"
            : "",
        emergencyContactNumber:
          employee.emergencyContactNumber &&
          employee.emergencyContactNumber.length !== 10
            ? "Emergency contact number must be exactly 10 digits"
            : "",
        gender: !employee.gender ? "Gender is required" : "",
        country: !employee.country ? "Country is required" : "",
        maritalStatus: !employee.maritalStatus
          ? "Marital status is required"
          : "",
        permanentAddress: !employee.permanentAddress
          ? "Permanent address is required"
          : "",
        dateOfJoining: !employee.dateOfJoining
          ? "Date of joining is required"
          : "",
        designation: !employee.designation ? "Designation is required" : "",
        jobTitle: !employee.jobTitle ? "Job title is required" : "",
        employeeType: !employee.employeeType ? "Employee type is required" : "",
        managerId: !employee.managerId ? "Manager is required" : "",
        departmentId: !employee.departmentId ? "Department is required" : "",
      });
      setTimeout(() => {
        setErrors({});
      }, 3000);
    }
  };

  const isFormValid = () => {
    const {
      firstName,
      lastName,
      emailId,
      dateOfBirth,
      contactNumber,
      emergencyContactNumber,
      gender,
      country,
      maritalStatus,
      permanentAddress,
      dateOfJoining,
      designation,
      jobTitle,
      employeeType,
      managerId,
      departmentId,
    } = employee;

    // Add your validation logic here
    // Return true if the form is valid, otherwise false
    return (
      firstName &&
      emailId &&
      isValidEmail(emailId) &&
      dateOfBirth &&
      contactNumber.length === 10 &&
      gender &&
      country &&
      maritalStatus &&
      permanentAddress &&
      dateOfJoining &&
      designation &&
      jobTitle &&
      employeeType &&
      managerId &&
      departmentId
    );
  };

  const isValidEmail = (email) => {
    // Simple email validation using regular expression
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  };

  const handleUpload = async (event) => {
    event.preventDefault();

    const file = event.target.files[0];

    if (file) {
      try {
        const response = await saveEmployeeFromExcel(file);
        setSuccessMessage("Employee data uploaded successfully!");
        setTimeout(() => {
          setSuccessMessage("");
        }, 3000);
        console.log(response);
      } catch (error) {
        console.error(error.message);
        setErrorMessage("Error uploading employee data."); // Set the error message
        setTimeout(() => {
          setErrorMessage("");
        }, 3000);
      }
    } else {
      setErrorMessage("Please select a file to upload."); // Set the error message
      setTimeout(() => {
        setErrorMessage("");
      }, 3000);
    }
  };

  const currentDate = new Date();
  const maxDateOfBirth = new Date(
    currentDate.getFullYear() - 18,
    currentDate.getMonth(),
    currentDate.getDate()
  )
    .toISOString()
    .split("T")[0];

  const eighteenYearsAgo = new Date(
    currentDate.getFullYear() - 18,
    currentDate.getMonth(),
    currentDate.getDate()
  );
  const minDateOfBirth = new Date(
    eighteenYearsAgo.getFullYear() - 100,
    eighteenYearsAgo.getMonth(),
    eighteenYearsAgo.getDate()
  )
    .toISOString()
    .split("T")[0];

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div className="add-employee-page">
        <div className="add-employee-container">
          <div className="add-employee-form">
            <h4
              style={{
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "2em",
              }}
            >
              <br />
              Add Employee
            </h4>
            <br />
            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group name-group">
                <div className="form-group">
                  <label>
                    First Name: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="firstName"
                    className="form-control"
                    value={employee.firstName}
                    onChange={handleChange}
                    required
                  />
                  {errors.firstName && (
                    <div className="employeeform-error-message">
                      {errors.firstName}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>Last Name:</label>
                  <input
                    type="text"
                    name="lastName"
                    className="form-control"
                    value={employee.lastName}
                    onChange={handleChange}
                  />
                  {errors.lastName && (
                    <div className="employeeform-error-message">
                      {errors.lastName}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group email-dob-group">
                <div className="form-group">
                  <label>
                    Email: <span className="required">*</span>
                  </label>
                  <input
                    type="email"
                    name="emailId"
                    className="form-control"
                    value={employee.emailId}
                    onChange={handleChange}
                    required
                  />
                  {errors.emailId && (
                    <div className="employeeform-error-message">
                      {errors.emailId}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>
                    Date of Birth: <span className="required">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfBirth"
                    className="form-control"
                    value={employee.dateOfBirth}
                    onChange={handleChange}
                    max={maxDateOfBirth}
                    min={minDateOfBirth}
                    required
                  />
                  {errors.dateOfBirth && (
                    <div className="employeeform-error-message">
                      {errors.dateOfBirth}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group contact-group">
                <div className="form-group">
                  <label>
                    Contact Number: <span className="required">*</span>
                  </label>
                  <input
                    type="number"
                    name="contactNumber"
                    className="form-control"
                    value={employee.contactNumber}
                    onChange={handleChange}
                    required
                    pattern="[0-9]{10}"
                    title="Contact number must be exactly 10 digits."
                  />
                  {errors.contactNumber && (
                    <div className="employeeform-error-message">
                      {errors.contactNumber}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>Emergency Contact Number:</label>
                  <input
                    type="number"
                    name="emergencyContactNumber"
                    className="form-control"
                    value={employee.emergencyContactNumber}
                    onChange={handleChange}
                    pattern="[0-9]{10}"
                    title="Emergency contact number must be exactly 10 digits."
                  />
                  {errors.emergencyContactNumber && (
                    <div className="employeeform-error-message">
                      {errors.emergencyContactNumber}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group gender-country-group">
                <div className="form-group">
                  <label>
                    Gender: <span className="required">*</span>
                  </label>
                  <select
                    name="gender"
                    className="form-control"
                    value={employee.gender}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Gender</option>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                  </select>
                  {errors.gender && (
                    <div className="employeeform-error-message">
                      {errors.gender}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>
                    Country: <span className="required">*</span>
                  </label>
                  <select
                    name="country"
                    className="form-control"
                    value={employee.country}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Country</option>
                    {countries.map((country) => (
                      <option key={country} value={country}>
                        {country}
                      </option>
                    ))}
                  </select>
                  {errors.country && (
                    <div className="employeeform-error-message">
                      {errors.country}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group marital-address-group">
                <div className="form-group">
                  <label>
                    Marital Status: <span className="required">*</span>
                  </label>
                  <select
                    name="maritalStatus"
                    className="form-control"
                    value={employee.maritalStatus}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Marital Status</option>
                    <option value="Single">Single</option>
                    <option value="Married">Married</option>
                  </select>
                  {errors.maritalStatus && (
                    <div className="employeeform-error-message">
                      {errors.maritalStatus}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>
                    Permanent Address: <span className="required">*</span>
                  </label>
                  <textarea
                    name="permanentAddress"
                    className="form-control"
                    value={employee.permanentAddress}
                    onChange={handleChange}
                    required
                  ></textarea>
                  {errors.permanentAddress && (
                    <div className="employeeform-error-message">
                      {errors.permanentAddress}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group joining-designation-group">
                <div className="form-group">
                  <label>
                    Date of Joining: <span className="required">*</span>
                  </label>
                  <input
                    type="date"
                    name="dateOfJoining"
                    className="form-control"
                    value={employee.dateOfJoining}
                    onChange={handleChange}
                    required
                  />
                  {errors.dateOfJoining && (
                    <div className="employeeform-error-message">
                      {errors.dateOfJoining}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>
                    Designation: <span className="required">*</span>
                  </label>
                  <input
                    type="text"
                    name="designation"
                    className="form-control"
                    value={employee.designation}
                    onChange={handleChange}
                    required
                  />
                  {errors.designation && (
                    <div className="employeeform-error-message">
                      {errors.designation}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group title-status-group">
                <div className="form-group">
                  <label>
                    Job Title: <span className="required">*</span>
                  </label>
                  <select
                    name="jobTitle"
                    className="form-control"
                    value={employee.jobTitle}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Job Title</option>
                    <option value="Full Stack Developer">
                      Full Stack Developer
                    </option>
                    <option value="Backend Developer">Backend Developer</option>
                    <option value="Frontend Developer">
                      Frontend Developer
                    </option>
                    <option value="Quality Assurance">Quality Assurance</option>
                    <option value="Payroll Manager">Payroll Manager</option>
                    <option value="Credit Analyst">Credit Analysis</option>
                    <option value="Budget Analyst">Budget Analyst</option>
                    <option value="Administrative Assistant">
                      Administrative Assistant
                    </option>
                    <option value="Executive Assistant">
                      Executive Assistant
                    </option>
                    <option value="Marketing Manager">Marketing Manager</option>
                    <option value="Customer Service Representative">
                      Customer Service Representative
                    </option>
                    <option value="Sales Manager">Sales Manager</option>
                  </select>
                  {errors.jobTitle && (
                    <div className="employeeform-error-message">
                      {errors.jobTitle}
                    </div>
                  )}
                </div>

                <div className="form-group">
                  <label>
                    Employee Type: <span className="required">*</span>
                  </label>
                  <select
                    name="employeeType"
                    className="form-control"
                    value={employee.employeeType}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Employee Type</option>
                    <option value="Hybrid">Hybrid</option>
                    <option value="Virtual">Virtual</option>
                  </select>
                  {errors.employeeType && (
                    <div className="employeeform-error-message">
                      {errors.employeeType}
                    </div>
                  )}
                </div>
              </div>

              <div className="form-group employee-info-group">
                <div className="form-group">
                  <label>
                    Department: <span className="required">*</span>
                  </label>
                  <select
                    name="departmentId"
                    className="form-control"
                    value={employee.departmentId}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Department</option>
                    {departments.map((department) => (
                      <option
                        key={department.departmentId}
                        value={department.departmentId}
                      >
                        {department.departmentName}
                      </option>
                    ))}
                  </select>
                  {errors.departmentId && (
                    <div className="employeeform-error-message">
                      {errors.departmentId}
                    </div>
                  )}
                </div>
                <div className="form-group">
                  <label>
                    Manager: <span className="required">*</span>
                  </label>
                  <select
                    name="managerId"
                    className="form-control"
                    value={employee.managerId}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Manager</option>
                    {employees.map((emp) => (
                      <option key={emp.id} value={emp.id}>
                        {emp.id + "."} {emp.firstName} {emp.lastName}
                        {" From: "}
                        {emp.department.departmentName}
                      </option>
                    ))}
                  </select>
                  {errors.managerId && (
                    <div className="employeeform-error-message">
                      {errors.managerId}
                    </div>
                  )}
                </div>
              </div>

              <Button
                type="submit"
                onClick={handleSubmit}
                className="btn-primary"
              >
                Add Employee
              </Button>

              <Button
                onClick={() => fileInputRef.current.click()}
                className="btn-secondary"
              >
                Bulk Upload
              </Button>
              <input
                type="file"
                id="uploadFile"
                style={{ display: "none" }}
                onChange={handleUpload}
                ref={fileInputRef}
              />
              {/* <div className="employee-form-go-back-button"> */}
              <NavLink exact to="/Dashboard">
                <br />
                <Button onClick={handleGoBack} className="btn-secondary">
                  Go Back
                </Button>
              </NavLink>
              {errorMessage && (
                <div className="employeeform-error-message">{errorMessage}</div>
              )}
              {successMessage && (
                <div className="employeeform-success-message">
                  {successMessage}
                </div>
              )}
              {/* </div> */}
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddEmployee;
