import React, { useEffect, useState } from "react";
import { Card } from "react-bootstrap";
import { BsCheckCircle, BsClock, BsXCircle } from "react-icons/bs";
import { getAllLeavesByEmployeeId } from "../../Service/LeaveApiService";
import { NavLink } from "react-router-dom";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import { useParams } from "react-router-dom";
import "./EmployeeLeaveCard.css";

export default function EmployeeLeaveCard() {
  const [leaves, setLeaves] = useState([]);
  const { employeeId } = useParams();

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllLeavesByEmployeeId(employeeId);
        setLeaves(data.data);
      } catch (error) {
        console.log("Error: ", error);
        // Handle the error or display an error message
      }
    };

    fetchData();
  }, []);

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>

      <div className="leave-card-list">
        {leaves.length === 0 ? (
          <div className="no-data-message">No Data of leaves</div>
        ) : (
          leaves.map((leave) => (
            <Card key={leave.leaveId} className="leave-card">
              <Card.Body>
                <div className="leave-card-header">
                  <Card.Title className="leave-type">
                    {leave.leaveCategory.leaveCategoryName}
                  </Card.Title>
                  <div className={`leave-status ${leave.status.toLowerCase()}`}>
                    {leave.status === "Approved" ? (
                      <BsCheckCircle className="leave-status-icon" />
                    ) : leave.status === "Pending" ? (
                      <BsClock className="leave-status-icon" />
                    ) : leave.status === "Rejected" ? (
                      <BsXCircle className="leave-status-icon" />
                    ) : null}
                    <span className="leave-status-text">{leave.status}</span>
                  </div>
                </div>
                <Card.Text className="leave-card-date">
                  Dates: {leave.startDate} to {leave.endDate}
                </Card.Text>
                <Card.Text className="leave-card-reason">
                  Reason: {leave.reason}
                </Card.Text>
              </Card.Body>
            </Card>
          ))
        )}
      </div>
      <div className="go-back-button">
        <NavLink exact to="/Employee-list">
          <button className="btn btn-primary">Go Back</button>
        </NavLink>
      </div>
    </>
  );
}
