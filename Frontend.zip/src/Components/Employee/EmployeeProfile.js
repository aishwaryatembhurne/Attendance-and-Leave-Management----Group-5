import React, { useEffect, useState } from "react";
import { NavLink } from "react-router-dom";
import Card from "react-bootstrap/Card";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import {
  getEmployeeById,
  updateEmployees,
} from "../../Service/EmployeeApiService";
import { AuthenticationAPI } from "../../Service/UserApiService";

import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import {
  faEdit,
  faSave,
  faEye,
  faEyeSlash,
  faTimes,
} from "@fortawesome/free-solid-svg-icons";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import "./EmployeeProfile.css";

const EmployeeDetailsPage = () => {
  const [employeeDetails, setEmployeeDetails] = useState({});
  const [editablePermanentAddress, setEditablePermanentAddress] = useState("");
  const [editableContactNumber, setEditableContactNumber] = useState("");
  const [isEditingContactNumber, setIsEditingContactNumber] = useState(false);
  const [editableEmergencyContactNumber, setEditableEmergencyContactNumber] =
    useState("");
  const [isEditingPermanentAddress, setIsEditingPermanentAddress] =
    useState(false);
  const [isEditingEmergencyContactNumber, setIsEditingEmergencyContactNumber] =
    useState(false);
  const [passwordUpdate, setPasswordUpdate] = useState({
    email: employeeDetails.emailId,
    newPassword: "",
  });
  const [editablePassword, setEditablePassword] = useState("");
  const [isEditingPassword, setIsEditingPassword] = useState(false);
  const [isPasswordVisible, setIsPasswordVisible] = useState(false);
  const [passwordValidationMessage, setPasswordValidationMessage] =
    useState("");
  const [passwordValidationColor, setPasswordValidationColor] = useState("red");

  useEffect(() => {
    const employeeId = sessionStorage.getItem("employeeId");
    getEmployeeById(employeeId)
      .then((response) => {
        setEmployeeDetails(response.data);
        setEditablePermanentAddress(response.data.permanentAddress);
        setEditableEmergencyContactNumber(response.data.emergencyContactNumber);
        setEditableContactNumber(response.data.contactNumber);
      })
      .catch((error) => {
        console.log(error);
      });
  }, []);

  const handleEditPermanentAddress = () => {
    setIsEditingPermanentAddress(true);
  };

  const handleSavePermanentAddress = () => {
    const updatedEmployeeDetails = {
      ...employeeDetails,
      permanentAddress: editablePermanentAddress,
    };
    updateEmployees(updatedEmployeeDetails)
      .then((response) => {
        console.log("Employee details updated successfully:", response.data);
        setIsEditingPermanentAddress(false);
        setEmployeeDetails(response.data);
      })
      .catch((error) => {
        console.log("Error updating employee details:", error);
      });
  };

  const handleCancelPermanentAddress = () => {
    setIsEditingPermanentAddress(false);
    setEditablePermanentAddress(employeeDetails.permanentAddress);
  };

  const handleEditContactNumber = () => {
    setIsEditingContactNumber(true);
  };

  const handleSaveContactNumber = () => {
    const updatedEmployeeDetails = {
      ...employeeDetails,
      contactNumber: editableContactNumber,
    };
    updateEmployees(updatedEmployeeDetails)
      .then((response) => {
        console.log("Employee details updated successfully:", response.data);
        setIsEditingContactNumber(false);
        setEmployeeDetails(response.data);
      })
      .catch((error) => {
        console.log("Error updating employee details:", error);
      });
  };

  const handleCancelContactNumber = () => {
    setIsEditingContactNumber(false);
    setEditableContactNumber(employeeDetails.contactNumber);
  };

  const handleContactNumberChange = (event) => {
    setEditableContactNumber(event.target.value);
  };

  const handleEditEmergencyContactNumber = () => {
    setIsEditingEmergencyContactNumber(true);
  };

  const handleSaveEmergencyContactNumber = () => {
    const updatedEmployeeDetails = {
      ...employeeDetails,
      emergencyContactNumber: editableEmergencyContactNumber,
    };
    updateEmployees(updatedEmployeeDetails)
      .then((response) => {
        console.log("Employee details updated successfully:", response.data);
        setIsEditingEmergencyContactNumber(false);
        setEmployeeDetails(response.data);
      })
      .catch((error) => {
        console.log("Error updating employee details:", error);
      });
  };

  const handleCancelEmergencyContactNumber = () => {
    setIsEditingEmergencyContactNumber(false);
    setEditableEmergencyContactNumber(employeeDetails.emergencyContactNumber);
  };

  const handlePermanentAddressChange = (event) => {
    setEditablePermanentAddress(event.target.value);
  };

  const handleEmergencyContactNumberChange = (event) => {
    setEditableEmergencyContactNumber(event.target.value);
  };

  const handleEditPassword = () => {
    setIsEditingPassword(true);
    setPasswordValidationMessage("");
  };

  // Helper function to validate password format
  const validatePassword = (password) => {
    const passwordRegex =
      /^(?=.*[a-zA-Z])(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,}$/;
    return passwordRegex.test(password);
  };

  const handleUpdatePassword = () => {
    if (validatePassword(editablePassword)) {
      const updatedPasswordUpdate = {
        ...passwordUpdate,
        email: employeeDetails.emailId,
        newPassword: editablePassword,
      };
      AuthenticationAPI.updatePassword(updatedPasswordUpdate)
        .then((response) => {
          console.log("Password updated successfully:", response);
          // Add any additional logic or UI changes upon successful password update
          setPasswordValidationMessage("");
          setPasswordValidationColor("green");

          // Reset password validation message after 3 seconds
          setTimeout(() => {
            setPasswordValidationMessage("");
            setPasswordValidationColor("red");
          }, 3000);
        })
        .catch((error) => {
          console.log("Error updating password:", error);
          // Handle and display the error to the user
        });
    } else {
      setPasswordValidationMessage(
        "Password must be at least 8 characters long and contain at least one special character and one number."
      );
      setPasswordValidationColor("red");

      // Reset password validation message after 3 seconds
      setTimeout(() => {
        setPasswordValidationMessage("");
        setPasswordValidationColor("red");
      }, 3000);
    }
  };

  const handleCancelPassword = () => {
    setIsEditingPassword(false);
    setEditablePassword("");
  };

  const handlePasswordChange = (event) => {
    const { value } = event.target;
    setEditablePassword(value);
  };
  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>

      <div style={{ marginLeft: "250px", marginTop: "60px" }}>
        <h1 style={{ marginLeft: "20px", marginTop: "70px", fontSize: "40px" }}>
          Employee Details
        </h1>
        {/* <Container className="employee-details-container"> */}
        {/* <Row> */}
        {/* <Col md={4}> */}
        <Card className="personal-details-card">
          <Card.Body>
            <Card.Title style={{ fontSize: "25px", fontWeight: "bold" }}>
              Personal Details
            </Card.Title>
            <Card.Text>
              <div className="details-item">
                <strong>Name:</strong> {employeeDetails.firstName}{" "}
                {employeeDetails.lastName}
              </div>
              <div className="details-item">
                <strong>Date of Birth:</strong> {employeeDetails.dateOfBirth}
              </div>
              <div className="details-item">
                <strong>Email:</strong> {employeeDetails.emailId}
              </div>
              <div className="details-item editable-field">
                <strong>Address:</strong>{" "}
                {isEditingPermanentAddress ? (
                  <>
                    <input
                      type="text"
                      value={editablePermanentAddress}
                      onChange={handlePermanentAddressChange}
                      // Bootstrap class for form inputs
                    />
                    <FontAwesomeIcon
                      icon={faSave}
                      className="ml-2 save-icon"
                      onClick={handleSavePermanentAddress}
                    />
                    <FontAwesomeIcon
                      icon={faTimes}
                      className="ml-2 cancel-icon"
                      onClick={handleCancelPermanentAddress}
                    />
                  </>
                ) : (
                  <>
                    {employeeDetails.permanentAddress}
                    <FontAwesomeIcon
                      icon={faEdit}
                      className="ml-2 edit-icon"
                      onClick={handleEditPermanentAddress}
                    />
                  </>
                )}
              </div>
              <div className="details-item">
                <strong>Gender:</strong> {employeeDetails.gender}
              </div>
              <div className="details-item">
                <strong>Contact Number:</strong>{" "}
                {isEditingContactNumber ? (
                  <>
                    <input
                      type="text"
                      value={editableContactNumber}
                      onChange={handleContactNumberChange}
                      style={{ width: "150px" }}
                      // className="form-control" // Bootstrap class for form inputs
                    />
                    <FontAwesomeIcon
                      icon={faSave}
                      className="ml-2 save-icon"
                      onClick={handleSaveContactNumber}
                    />
                    <FontAwesomeIcon
                      icon={faTimes}
                      className="ml-2 cancel-icon"
                      onClick={handleCancelContactNumber}
                    />
                  </>
                ) : (
                  <>
                    {employeeDetails.contactNumber}
                    <FontAwesomeIcon
                      icon={faEdit}
                      className="ml-2 edit-icon"
                      onClick={handleEditContactNumber}
                    />
                  </>
                )}
              </div>

              <div className="details-item">
                <strong>Emergency Contact Number:</strong>{" "}
                {isEditingEmergencyContactNumber ? (
                  <>
                    <input
                      type="text"
                      value={editableEmergencyContactNumber}
                      onChange={handleEmergencyContactNumberChange}
                      style={{ width: "150px" }} // className="form-control" // Bootstrap class for form inputs
                    />
                    <FontAwesomeIcon
                      icon={faSave}
                      className="ml-2 save-icon"
                      onClick={handleSaveEmergencyContactNumber}
                    />
                    <FontAwesomeIcon
                      icon={faTimes}
                      className="ml-2 cancel-icon"
                      onClick={handleCancelEmergencyContactNumber}
                    />
                  </>
                ) : (
                  <>
                    {employeeDetails.emergencyContactNumber}
                    <FontAwesomeIcon
                      icon={faEdit}
                      className="ml-2 edit-icon"
                      onClick={handleEditEmergencyContactNumber}
                    />
                  </>
                )}
              </div>
              <div className="details-item">
                <strong>Marital Status:</strong> {employeeDetails.maritalStatus}
              </div>
              <div className="details-item">
                <strong>Password:</strong>{" "}
                {isEditingPassword ? (
                  <>
                    <input
                      type={isPasswordVisible ? "text" : "password"}
                      value={editablePassword}
                      onChange={handlePasswordChange}
                      style={{ width: "150px" }}
                    />
                    <FontAwesomeIcon
                      icon={faEye}
                      className="ml-2 eye-icon"
                      onClick={() => setIsPasswordVisible(!isPasswordVisible)}
                    />
                    <FontAwesomeIcon
                      icon={faSave}
                      className="ml-2 save-icon"
                      onClick={handleUpdatePassword}
                    />
                    <FontAwesomeIcon
                      icon={faTimes}
                      className="ml-2 cancel-icon"
                      onClick={handleCancelPassword}
                    />
                  </>
                ) : (
                  <>
                    {employeeDetails.password}
                    <FontAwesomeIcon
                      icon={faEdit}
                      className="ml-2 edit-icon"
                      onClick={handleEditPassword}
                    />
                  </>
                )}
              </div>
              {passwordValidationMessage && (
                <div style={{ color: passwordValidationColor }}>
                  {passwordValidationMessage}
                </div>
              )}
            </Card.Text>
          </Card.Body>
        </Card>
        {/* </Col> */}
        {/* <Col md={4}> */}
        <Card className="employment-details-card">
          <Card.Body>
            <Card.Title
              style={{
                fontSize: "25px",
                fontWeight: "bold",
              }}
            >
              Employment Details
            </Card.Title>
            <Card.Text>
              <div className="details-item">
                <strong>Status:</strong> {employeeDetails.status}
              </div>
              <div className="details-item">
                <strong>Date of Joining:</strong>{" "}
                {employeeDetails.dateOfJoining}
              </div>
              <div className="details-item">
                <strong>Designation:</strong> {employeeDetails.designation}
              </div>
              <div className="details-item">
                <strong>Job Title:</strong> {employeeDetails.jobTitle}
              </div>
              <div className="details-item">
                <strong>Department:</strong>{" "}
                {employeeDetails.department &&
                  employeeDetails.department.departmentName}
              </div>
              <div className="details-item">
                <strong>Employee Type:</strong> {employeeDetails.employeeType}
              </div>
            </Card.Text>
          </Card.Body>
        </Card>
        {/* </Col> */}
        {/* </Row> */}
        {/* </Container> */}
        <div className="employeeprofile-go-back-button">
          <NavLink exact to="/Dashboard">
            <button className="btn btn-primary">Go Back</button>
          </NavLink>
        </div>
      </div>
    </>
  );
};

export default EmployeeDetailsPage;
