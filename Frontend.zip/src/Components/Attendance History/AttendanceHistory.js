import React, { useState, useEffect } from "react";
import NavigationBar from "../NavigationBar";
import { NavLink } from "react-router-dom";
import Sidebar from "../Sidebar";
import "./AttendanceHistory.css";
import {
  exportAttendanceToPDF,
  getEmployeeAttendance,
  updateAttendance,
} from "../../Service/AttendanceApiService";
import { format, startOfMonth, endOfMonth, isAfter } from "date-fns";
import { Pagination } from "react-bootstrap";
const AttendanceHistory = () => {
  const storedEmployeeId = sessionStorage.getItem("employeeId");
  const currentDate = new Date();
  const currentMonthStartDate = new Date(
    currentDate.getFullYear(),
    currentDate.getMonth(),
    2
  );
  const currentMonthEndDate = currentDate;
  const formattedStartDate = currentMonthStartDate.toISOString().split("T")[0];
  const [startDate, setStartDate] = useState(formattedStartDate);
  const [endDate, setEndDate] = useState(
    currentMonthEndDate.toISOString().split("T")[0]
  );
  const [attendanceData, setAttendanceData] = useState([]);
  const [validationError, setValidationError] = useState("");
  const employeeId = storedEmployeeId;
  const [currentPage, setCurrentPage] = useState(1);
  const [attendancePerPage] = useState(8);

  const handleSearch = async () => {
    try {
      if (employeeId && startDate && endDate) {
        if (endDate < startDate) {
          setValidationError("End date should not be less than start date.");
          return;
        }
        const response = await getEmployeeAttendance(
          employeeId,
          startDate,
          endDate
        );
        const sortedData = response.sort(
          (a, b) => new Date(b.attendanceDate) - new Date(a.attendanceDate)
        );
        setAttendanceData(sortedData);
        console.log("Attendance Data: ", sortedData);
        setValidationError("");
      } else {
        setAttendanceData([]);
        setValidationError("");
      }
    } catch (error) {
      console.error(error);
      setValidationError("");
    }
  };

  const handleDownload = async () => {
    try {
      if (employeeId && startDate && endDate) {
        if (endDate < startDate) {
          setValidationError("End date should not be less than start date.");
          return;
        }
        const attendancePdf = await exportAttendanceToPDF(
          employeeId,
          startDate,
          endDate
        );
        // Create a Blob object from the binary data
        const blob = new Blob([attendancePdf], { type: "application/pdf" });
        // Generate a URL for the blob object
        const url = URL.createObjectURL(blob);
        // Create a temporary link element
        const link = document.createElement("a");
        link.href = url;
        link.download = "attendance.pdf"; // Set the desired filename for the downloaded file
        // Programmatically click the link to trigger the download
        link.click();
        // Clean up the temporary URL and link element
        URL.revokeObjectURL(url);
      }
    } catch (error) {
      console.error(error);
      // Handle the error or display an error message
    }
  };

  const handleSearchButtonClick = () => {
    handleSearch();
  };

  const handleStartDateChange = (event) => {
    setStartDate(event.target.value);
    if (endDate && isAfter(endDate, event.target.value)) {
      setValidationError("End date should not be less than start date.");
    } else {
      setValidationError("");
    }
  };

  const handleEndDateChange = (event) => {
    setEndDate(event.target.value);
    if (startDate && isAfter(startDate, event.target.value)) {
      setValidationError("End date should not be less than start date.");
    } else {
      setValidationError("");
    }
  };

  const handleUpdateAttendanceStatus = async (storedEmployeeId, newStatus) => {
    try {
      await updateAttendance(storedEmployeeId, newStatus);
      setAttendanceData((prevAttendanceData) =>
        prevAttendanceData.map((attendance) =>
          attendance.attendanceId === storedEmployeeId
            ? { ...attendance, status: newStatus }
            : attendance
        )
      );
      window.location.reload();
    } catch (error) {
      console.log("Error: ", error);
      // Handle the error or display an error message
    }
  };

  useEffect(() => {
    handleSearch();
  }, [employeeId]);

  const indexOfLastAttendance = currentPage * attendancePerPage;
  const indexOfFirstAttendance = indexOfLastAttendance - attendancePerPage;
  const currentAttendance = attendanceData.slice(
    indexOfFirstAttendance,
    indexOfLastAttendance
  );

  const paginate = (pageNumber) => setCurrentPage(pageNumber);
  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div className="employee-attendance-container">
        <h2>Employee Attendance</h2>
        <div className="date-selector">
          <label htmlFor="startDate">Start Date:</label>
          <input
            type="date"
            id="startDate"
            value={startDate}
            onChange={handleStartDateChange}
            className="date-input"
          />
          <label htmlFor="endDate">End Date:</label>
          <input
            type="date"
            id="endDate"
            value={endDate}
            onChange={handleEndDateChange}
            className="date-input"
          />
          <button onClick={handleSearchButtonClick} className="search-button">
            Search
          </button>

          <div className="attendancehistory-button-container">
            <button
              onClick={handleDownload}
              className="attendancehistory-export-button download-button"
            >
              Download PDF
            </button>
          </div>
        </div>
        {validationError && (
          <div className="attendancehistory-error-message">
            {validationError}
          </div>
        )}
        <table className="employee-attendance-table">
          <thead>
            <tr>
              <th>Date</th>
              <th>Time</th>
              <th>Work Mode</th>
              <th>Status</th>
              <th>Update Status</th>
            </tr>
          </thead>
          <tbody>
            {Array.isArray(currentAttendance) &&
            currentAttendance.length > 0 ? (
              currentAttendance
                .slice()

                .map((attendance) => (
                  <tr
                    key={attendance.attendanceId}
                    className={
                      attendance.attendanceStatus === "Present"
                        ? "present-row"
                        : "absent-row"
                    }
                  >
                    <td>{attendance.attendanceDate}</td>
                    <td>{attendance.attendanceTime}</td>
                    <td>{attendance.workMode}</td>
                    <td>
                      <span
                        className={
                          attendance.attendanceStatus === "Present"
                            ? "status-active"
                            : "status-inactive"
                        }
                      >
                        {attendance.attendanceStatus}
                      </span>
                    </td>
                    <td>
                      {attendance.attendanceStatus === "Present" ||
                      attendance.attendanceStatus === "Absent" ? (
                        attendance.attendanceStatus === "Present" ? (
                          <button
                            onClick={() =>
                              handleUpdateAttendanceStatus(
                                attendance.attendanceId,
                                "Absent"
                              )
                            }
                            className="status-button absent-button"
                          >
                            Mark Absent
                          </button>
                        ) : (
                          <button
                            onClick={() =>
                              handleUpdateAttendanceStatus(
                                attendance.attendanceId,
                                "Present"
                              )
                            }
                            className="status-button present-button"
                          >
                            Mark Present
                          </button>
                        )
                      ) : (
                        <span>NA</span>
                      )}
                    </td>
                  </tr>
                ))
            ) : (
              <tr>
                <td colSpan="5" className="no-data-message text-center">
                  No data available between the selected dates.
                </td>
              </tr>
            )}
          </tbody>
        </table>

        <div className="attendancehistory-pagination-container">
          <Pagination>
            <Pagination.Prev
              onClick={() => paginate(currentPage - 1)}
              disabled={currentPage === 1}
            />
            {Array(Math.ceil(attendanceData.length / attendancePerPage))
              .fill()
              .map((_, index) => (
                <Pagination.Item
                  key={index + 1}
                  active={index + 1 === currentPage}
                  onClick={() => paginate(index + 1)}
                >
                  {index + 1}
                </Pagination.Item>
              ))}
            <Pagination.Next
              onClick={() => paginate(currentPage + 1)}
              disabled={
                currentPage ===
                Math.ceil(attendanceData.length / attendancePerPage)
              }
            />
          </Pagination>
        </div>
      </div>
      <div className="attendancehistory-go-back-button">
        <NavLink exact to="/Dashboard">
          <button className="btn btn-primary">Go Back</button>
        </NavLink>
      </div>
    </>
  );
};

export default AttendanceHistory;
