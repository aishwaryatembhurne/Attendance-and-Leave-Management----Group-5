import React, { useState, useRef, useEffect } from "react";
import { Button, NavLink } from "react-bootstrap";
import "./RosterForm.css";
import { createRoster, uploadFile } from "../../Service/RosterApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import { useNavigate } from "react-router-dom";
import { getAllEmployee } from "../../Service/EmployeeApiService";

const AddRoster = () => {
  const [roster, setRoster] = useState({
    employeeId: "",
    rosterDate: "",
    rosterType: "",
  });

  const [errors, setErrors] = useState({
    employeeId: "",
    rosterDate: "",
    rosterType: "",
  });

  const [successMessage, setSuccessMessage] = useState("");
  const [message, setMessage] = useState("");
  const [employees, setEmployees] = useState([]);

  const fileInputRef = useRef(null);

  useEffect(() => {
    fetchEmployees();
  }, []);

  const fetchEmployees = async () => {
    try {
      const response = await getAllEmployee();
      setEmployees(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const handleChange = (event) => {
    const { name, value } = event.target;

    if (name === "rosterType" && !/^[a-zA-Z\s]*$/.test(value)) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        rosterType: "Only string values are allowed",
      }));
      setTimeout(() => {
        setErrors((prevErrors) => ({
          ...prevErrors,
          rosterType: "",
        }));
      }, 3000);
    } else {
      setErrors((prevErrors) => ({
        ...prevErrors,
        rosterType: "",
      }));
      setRoster((prevRoster) => ({
        ...prevRoster,
        [name]: value,
      }));
    }
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = { ...errors };

    if (!roster.employeeId) {
      newErrors.employeeId = "Employee ID is required";
      isValid = false;
    } else {
      newErrors.employeeId = "";
    }

    if (!roster.rosterDate) {
      newErrors.rosterDate = "Roster Date is required";
      isValid = false;
    } else {
      newErrors.rosterDate = "";
    }

    if (!roster.rosterType) {
      newErrors.rosterType = "Roster Type is required";
      isValid = false;
    } else {
      newErrors.rosterType = "";
    }

    setErrors(newErrors);

    if (!isValid) {
      setTimeout(() => {
        setErrors({});
      }, 3000);
    }

    return isValid;
  };

  const navigate = useNavigate();
  const handleGoBack = () => {
    navigate("/Dashboard");
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (validateForm()) {
      createRoster(roster)
        .then((response) => {
          setSuccessMessage("Roster added successfully!");
          console.log(response);

          setRoster({
            employeeId: "",
            rosterDate: "",
            rosterType: "",
          });

          setTimeout(() => {
            setSuccessMessage(""); // Remove success message after 3 seconds
          }, 3000);
        })
        .catch((error) => {
          console.error(error.message);
        });
    }
  };

  const handleUpload = (event) => {
    const file = event.target.files[0];

    if (file) {
      uploadFile(file)
        .then((response) => {
          setSuccessMessage("File uploaded successfully!");
          console.log(response);

          setTimeout(() => {
            setSuccessMessage(""); // Remove success message after 3 seconds
          }, 3000);
        })
        .catch((error) => {
          console.error(error);
        });
    } else {
      setMessage("Please select a file to upload.");
    }
  };

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div className="add-roster-page">
        <div className="add-roster-container">
          <div className="add-roster-form">
            <h4
              style={{
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "2em",
              }}
            >
              Roster Form
            </h4>
            <br />

            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label>
                  Employee ID: <span className="required">*</span>
                </label>
                <select
                  name="employeeId"
                  className="form-control"
                  value={roster.employeeId}
                  onChange={handleChange}
                  required
                >
                  <option value="">Select Employee</option>
                  {employees.map((emp) => (
                    <option key={emp.id} value={emp.id}>
                      {emp.id}.{emp.firstName} {emp.lastName} From:{" "}
                      {emp.department.departmentName}
                    </option>
                  ))}
                </select>
                {errors.employeeId && (
                  <div className="rosterform-error-message">
                    {errors.employeeId}
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>
                  Roster Date: <span className="required">*</span>
                </label>
                <input
                  type="date"
                  name="rosterDate"
                  className="form-control"
                  value={roster.rosterDate}
                  onChange={handleChange}
                  required
                />
                {errors.rosterDate && (
                  <div className="rosterform-error-message">
                    {errors.rosterDate}
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>
                  Roster Type: <span className="required">*</span>
                </label>
                <input
                  type="text"
                  name="rosterType"
                  className="form-control"
                  value={roster.rosterType}
                  onChange={handleChange}
                  required
                />
                {errors.rosterType && (
                  <div className="rosterform-error-message">
                    {errors.rosterType}
                  </div>
                )}
              </div>

              <Button type="submit" className="btn-primary">
                Add Roster
              </Button>

              <input
                type="file"
                accept=".xlsx, .xls"
                style={{ display: "none" }}
                onChange={handleUpload}
                ref={fileInputRef}
              />
              <Button
                className="btn-primary"
                onClick={() => fileInputRef.current.click()}
              >
                Upload
              </Button>

              <NavLink exact to="/Dashboard">
                <Button onClick={handleGoBack} className="btn-secondary">
                  Go Back
                </Button>
              </NavLink>

              {successMessage && (
                <div className="rosterform-success-message">
                  {successMessage}
                </div>
              )}

              {message && <div className="message">{message}</div>}
            </form>
          </div>
        </div>
      </div>
    </>
  );
};

export default AddRoster;
