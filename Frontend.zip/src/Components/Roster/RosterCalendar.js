import React, { useState, useEffect } from "react";
import { Container, Row, Col, Button } from "react-bootstrap";
import styled from "styled-components";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import { getEmployeeRoster } from "../../Service/RosterApiService";
import { NavLink } from "react-router-dom";

const Frame = styled.div`
  width: 1137px;
  height: 584px;
  margin-top: 120px;
  margin-left: 320px;
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #04526b;
  padding: 10px;
  border-radius: 5px;
  font-family: "Raleway", sans-serif; /* Update font family */

  h2 {
    color: white;
    margin: 0;
    margin-left: 420px;
  }

  .month {
    margin-left: 275px;
    font-weight: bold;
    font-size: 25px;
  }
`;

const Body = styled.div`
  height: 400px;
  display: flex;
  flex-wrap: wrap;
  border-radius: 10px;
  font-family: "Raleway", sans-serif; /* Update font family */
`;

const Day = styled.div`
  width: 162px;
  height: 75px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-direction: column;
  border: 1px solid #eee;
  background-color: #ffd9ed;
  border-radius: 5px;
  border-color: black;
  font-family: "Raleway", sans-serif /* Update font family */ &.today {
    border: 1px solid #eee;
  }

  &.selected {
    background-color: #fff2ed;
  }

  .roster-entry {
    margin-bottom: 5px;
    font-weight: bold;
  }
`;

const CalendarContainer = styled.div`
  position: relative;
  font-family: "Raleway", sans-serif; /* Update font family */
`;

const DateInputContainer = styled.div`
  position: absolute;
  margin-top: 65px;
  top: 10px;
  left: 320px;
  right: 700px;
  display: flex;
  align-items: center;
  width: 1140px;

  label {
    margin-right: 5px;
    font-size: 16px;
    color: Black;
    font-weight: bold;
  }

  .form-control {
    margin-right: 10px;
    width: 125px;
    height: 40px;
    font-size: 15px;
  }

  .roster-calendar-go-back-button {
    margin-left: 503px;
  }

  button {
    padding: 5px 10px;
    width: 100px;
    font-size: 14px;
    height: 40px;
    margin-top: 0;
    background-color: #04526b;
  }

  button:hover {
    background-color: #36433d; /* Set the desired hover color */
  }
`;

const OuterContainer = styled.div`
  position: relative;
`;
export function Calendar() {
  const DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const DAYS_LEAP = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const DAYS_OF_THE_WEEK = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const MONTHS = [
    "JAN",
    "FEB",
    "MAR",
    "APR",
    "MAY",
    "JUN",
    "JUL",
    "AUG",
    "SEP",
    "OCT",
    "NOV",
    "DEC",
  ];

  const today = new Date();
  const lastDayOfMonth = new Date(
    today.getFullYear(),
    today.getMonth() + 1,
    0
  ).getDate();
  const defaultStartDate = new Date(today.getFullYear(), today.getMonth(), 2)
    .toISOString()
    .split("T")[0];
  const defaultEndDate = `${today.getFullYear()}-${String(
    today.getMonth() + 1
  ).padStart(2, "0")}-${String(lastDayOfMonth).padStart(2, "0")}`;

  const [date, setDate] = useState(today);
  const [day, setDay] = useState(date.getDate());
  const [month, setMonth] = useState(date.getMonth());
  const [year, setYear] = useState(date.getFullYear());
  const [startDay, setStartDay] = useState(getStartDayOfMonth(date));
  const [rosterData, setRosterData] = useState([]);
  const [startDate, setStartDate] = useState(defaultStartDate);
  const [endDate, setEndDate] = useState(defaultEndDate);

  useEffect(() => {
    setDay(date.getDate());
    setMonth(date.getMonth());
    setYear(date.getFullYear());
    setStartDay(getStartDayOfMonth(date));

    const employeeId = sessionStorage.getItem("employeeId");
    if (employeeId && startDate && endDate) {
      fetchEmployeeRoster(employeeId, startDate, endDate);
    }
  }, [date]);

  function getStartDayOfMonth(date) {
    const startDate = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return startDate === 0 ? 7 : startDate;
  }

  function isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  }

  const days = isLeapYear(year) ? DAYS_LEAP : DAYS;

  const fetchEmployeeRoster = async () => {
    try {
      const employeeId = sessionStorage.getItem("employeeId");
      if (employeeId && startDate && endDate) {
        const start = new Date(startDate);
        const end = new Date(endDate);
        start.setHours(0, 0, 0, 0);
        end.setHours(23, 59, 59, 999);
        const response = await getEmployeeRoster(
          employeeId,
          start.toISOString().split("T")[0],
          end.toISOString().split("T")[0]
        );
        setRosterData(response.data);
        console.log("Fetched roster data:", response.data);
      }
    } catch (error) {
      console.log("Error fetching employee roster:", error);
    }
  };

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <DateInputContainer>
        <label htmlFor="start-date">Start Date:</label>
        <input
          type="date"
          id="start-date"
          className="form-control"
          value={startDate}
          onChange={(e) => setStartDate(e.target.value)}
        />

        <label htmlFor="end-date">End Date:</label>
        <input
          type="date"
          id="end-date"
          className="form-control"
          value={endDate}
          onChange={(e) => setEndDate(e.target.value)}
        />
        <Button variant="primary" onClick={fetchEmployeeRoster}>
          Fetch Roster
        </Button>
        <div className="roster-calendar-go-back-button">
          <NavLink exact to="/Dashboard">
            <button className="btn btn-primary ">Go Back</button>
          </NavLink>
        </div>
      </DateInputContainer>
      <OuterContainer>
        <Frame>
          <Header>
            <Button
              variant="outline-primary" // Updated variant
              onClick={() => setDate(new Date(year, month - 1, day))}
              style={{
                color: "white",
                borderColor: "white",
              }}
            >
              Prev
            </Button>
            <h2>Roster</h2>
            <div className="month" style={{ color: "white" }}>
              {MONTHS[month]} {year}
            </div>
            <Button
              variant="outline-primary"
              onClick={() => setDate(new Date(year, month + 1, day))}
              style={{
                color: "white",
                borderColor: "white",
              }}
            >
              Next
            </Button>
          </Header>
          <CalendarContainer>
            <Body>
              {DAYS_OF_THE_WEEK.map((d) => (
                <Day key={d}>
                  <strong>{d}</strong>
                </Day>
              ))}
              {Array(days[month] + (startDay - 1))
                .fill(null)
                .map((_, index) => {
                  const d = index - (startDay - 2);
                  const rosterDay = new Date(year, month, d);
                  const isSelected = d === day;
                  const isToday =
                    rosterDay.toDateString() === today.toDateString();
                  const rosterEntries = rosterData.filter(
                    (roster) =>
                      new Date(roster.rosterDate).toDateString() ===
                      rosterDay.toDateString()
                  );

                  return (
                    <Day
                      key={index}
                      className={`${isToday ? "today" : ""} ${
                        isSelected ? "selected" : ""
                      }`}
                      onClick={() => setDate(new Date(year, month, d))}
                    >
                      {d > 0 && (
                        <>
                          {rosterEntries.map((entry) => (
                            <div className="roster-entry" key={entry.rosterId}>
                              <div>{entry.rosterType}</div>
                              <div>{entry.employee.name}</div>
                            </div>
                          ))}
                          {d}
                        </>
                      )}
                    </Day>
                  );
                })}
            </Body>
          </CalendarContainer>
        </Frame>
      </OuterContainer>
    </>
  );
}

export default Calendar;
