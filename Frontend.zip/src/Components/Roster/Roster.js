import React from "react";
import Calendar from "../Roster/RosterCalendar";

const RosterPage = () => {
  return (
    <div>
      <Calendar />
    </div>
  );
};

export default RosterPage;
