import React, { useEffect, useState } from "react";
import { Navbar, Nav, Image, Button, Modal } from "react-bootstrap";
import { Link, useNavigate } from "react-router-dom";
import { getEmployeeById } from "../Service/EmployeeApiService";
import man from "../Assets/male.png";
import woman from "../Assets/female.png";
import "../Components/css/NavigationBar.css";

const NavigationBar = () => {
  const navigate = useNavigate();
  const [employee, setEmployee] = useState({});
  const [showProfile, setShowProfile] = useState(false);

  useEffect(() => {
    getEmployeeDetails();
  }, []);

  async function getEmployeeDetails() {
    try {
      const employeeId = sessionStorage.getItem("employeeId");
      const response = await getEmployeeById(employeeId);
      setEmployee(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  const logout = () => {
    sessionStorage.removeItem("token");
    sessionStorage.setItem("login", false);
    sessionStorage.removeItem("employeeId");
    sessionStorage.removeItem("departmentId");
    navigate("/");
  };

  const handleProfileClick = () => {
    setShowProfile(true);
  };

  const handleCloseProfile = () => {
    setShowProfile(false);
  };

  return (
    <Navbar expand="lg" fixed="top" className="navbar">
      <Navbar.Toggle aria-controls="navbar-nav" />
      <h3 className="text-white padding">
        Attendance and Leave Management System
      </h3>
      <Navbar.Collapse id="navbar-nav" className="justify-content-end">
        <Navbar.Brand className="mr-auto" onClick={handleProfileClick}>
          <span className="employee-name">
            {employee.gender === "Male" && (
              <Image
                src={man}
                alt="Profile Picture"
                roundedCircle
                width={30}
                height={30}
                className="mr-2"
              />
            )}
            {employee.gender === "Female" && (
              <Image
                src={woman}
                alt="Profile Picture"
                roundedCircle
                width={30}
                height={30}
                className="mr-2"
              />
            )}
            <span>
              {employee.firstName} {employee.lastName}
            </span>
          </span>
        </Navbar.Brand>
        <Nav>
          <Nav.Link as={Link} to="/dashboard" exact>
            Dashboard
          </Nav.Link>
          <Button variant="outline-light" className="ml-2" onClick={logout}>
            Logout
          </Button>
        </Nav>
      </Navbar.Collapse>
      <EmployeeShortProfile
        employee={employee}
        show={showProfile}
        handleClose={handleCloseProfile}
      />
    </Navbar>
  );
};

const EmployeeShortProfile = ({
  employee,
  show,
  handleClose,
  handleDetailProfileClick,
}) => {
  return (
    <Modal show={show} onHide={handleClose} className="employee-profile">
      <Modal.Header closeButton>
        <Modal.Title>Employee Profile</Modal.Title>
      </Modal.Header>
      <Modal.Body>
        <p>
          <strong>Name: </strong>
          <span>{employee.firstName} </span>
          <span>{employee.lastName}</span>
        </p>
        <p>
          <strong>Email: </strong> {employee.emailId}
        </p>
        <p>
          <strong>Date of Joining: </strong> {employee.dateOfJoining}
        </p>
        <p>
          <strong>EmployeeType: </strong> {employee.employeeType}
        </p>
      </Modal.Body>
      <Modal.Footer>
        <Button variant="secondary" onClick={handleClose}>
          Close
        </Button>
        <Nav.Link as={Link} to="/employee-profile" exact>
          <Button variant="primary">Detail Profile</Button>
        </Nav.Link>
      </Modal.Footer>
    </Modal>
  );
};

export default NavigationBar;
