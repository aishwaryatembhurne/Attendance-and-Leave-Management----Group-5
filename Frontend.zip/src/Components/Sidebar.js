import { NavLink } from "react-router-dom";
import {
  FaClipboardList,
  FaHistory,
  FaUsers,
  FaCalendarAlt,
} from "react-icons/fa";
import { AiOutlineFileAdd, AiOutlineClockCircle } from "react-icons/ai";
import { RiCalendarTodoLine, RiUserAddLine } from "react-icons/ri";
import "./css/Sidebar.css";
import {
  getEmployeeById,
  getEmployeesByManagerId,
} from "../Service/EmployeeApiService";
import { useEffect, useState } from "react";

const Sidebar = () => {
  const role = sessionStorage.getItem("role");
  // console.log("role is ", role);
  const [employee, setEmployee] = useState([]);
  const employeeId = sessionStorage.getItem("employeeId");

  useEffect(() => {
    getAllEmployees();
  }, []);

  async function getAllEmployees() {
    try {
      const managerId = sessionStorage.getItem("employeeId"); // Replace with the actual manager ID
      const response = await getEmployeeById(managerId);
      setEmployee(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  return (
    <div className="sidebar  text-white p-4 ">
      <NavLink
        exact
        to="/apply-leave"
        activeClassName="active"
        className="sidebar-link"
      >
        <div className="sidebar-button">
          <FaClipboardList className="sidebar-icon" />
          <span className="sidebar-text">Apply Leave</span>
        </div>
      </NavLink>
      <NavLink
        exact
        to="/attendance-history"
        activeClassName="active"
        className="sidebar-link"
      >
        <div className="sidebar-button">
          <AiOutlineClockCircle className="sidebar-icon" />
          <span className="sidebar-text">Attendance history</span>
        </div>
      </NavLink>

      <NavLink
        exact
        to="/leave-history"
        activeClassName="active"
        className="sidebar-link"
      >
        <div className="sidebar-button">
          <FaHistory className="sidebar-icon" />
          <span className="sidebar-text">Leave History</span>
        </div>
      </NavLink>
      {employee.employeeType === "Hybrid" && (
        <NavLink
          exact
          to="/roster-calendar"
          activeClassName="active"
          className="sidebar-link"
        >
          <div className="sidebar-button">
            <FaCalendarAlt className="sidebar-icon" />
            <span className="sidebar-text">Roster</span>
          </div>
        </NavLink>
      )}
      <NavLink
        exact
        to="/holiday-calendar"
        activeClassName="active"
        className="sidebar-link"
      >
        <div className="sidebar-button">
          <FaCalendarAlt className="sidebar-icon" />
          <span className="sidebar-text">Holiday Calendar</span>
        </div>
      </NavLink>

      {/* Display for Manager or Admin role */}
      {(role === "MANAGER" || role === "ADMIN") && (
        <div>
          <NavLink
            exact
            to="/employee-list"
            activeClassName="active"
            className="sidebar-link"
          >
            <div className="sidebar-button">
              <FaUsers className="sidebar-icon" />
              <span className="sidebar-text">Employee List</span>
            </div>
          </NavLink>
          <NavLink
            exact
            to="/pending-leaves"
            activeClassName="active"
            className="sidebar-link"
          >
            <div className="sidebar-button">
              <RiCalendarTodoLine className="sidebar-icon" />
              <span className="sidebar-text">Pending Leaves</span>
            </div>
          </NavLink>
        </div>
      )}

      {/* Display for Admin or HR role */}
      {(role === "ADMIN" || role === "HR") && (
        <div>
          <NavLink
            exact
            to="/all-employees"
            activeClassName="active"
            className="sidebar-link"
          >
            <div className="sidebar-button">
              <FaUsers className="sidebar-icon" />
              <span className="sidebar-text">All Employees</span>
            </div>
          </NavLink>
          <NavLink
            exact
            to="/add-employee"
            activeClassName="active"
            className="sidebar-link"
          >
            <div className="sidebar-button">
              <RiUserAddLine className="sidebar-icon" />
              <span className="sidebar-text">Add Employee</span>
            </div>
          </NavLink>
          <NavLink
            exact
            to="/add-holiday"
            activeClassName="active"
            className="sidebar-link"
          >
            <div className="sidebar-button">
              <AiOutlineFileAdd className="sidebar-icon" />
              <span className="sidebar-text">Add Holiday</span>
            </div>
          </NavLink>
          <NavLink
            exact
            to="/add-roster"
            activeClassName="active"
            className="sidebar-link"
          >
            <div className="sidebar-button">
              <AiOutlineFileAdd className="sidebar-icon" />
              <span className="sidebar-text">Add Roster</span>
            </div>
          </NavLink>
        </div>
      )}
    </div>
  );
};

export default Sidebar;
