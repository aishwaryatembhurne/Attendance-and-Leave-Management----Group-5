import React, { useState, useEffect } from "react";
import { Table, Button } from "react-bootstrap";
import { useNavigate, NavLink } from "react-router-dom";
import {
  getAllLeavesByManagerId,
  updateLeave,
} from "../../Service/LeaveApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";

const LeaveTable = () => {
  const [leaves, setLeaves] = useState([]);
  const navigate = useNavigate();
  const employeeId = sessionStorage.getItem("employeeId");

  useEffect(() => {
    const fetchLeaves = async () => {
      try {
        const response = await getAllLeavesByManagerId(employeeId);
        setLeaves(response.data); // Assuming response.data is the array of leaves
      } catch (error) {
        console.log("Error fetching leaves:", error);
      }
    };

    fetchLeaves();
  }, []);

  const handleApprove = async (leaveId) => {
    try {
      console.log("leave id to be approved is:", leaveId);
      // Make the API call to update the leave status to "approved"
      await updateLeave(Number(leaveId), "Approved");

      // After successful update, refresh the page
      window.location.reload();
    } catch (error) {
      console.log("Error approving leave:", error);
    }
  };

  const handleReject = async (leaveId) => {
    try {
      // Make the API call to update the leave status to "rejected"
      await updateLeave(Number(leaveId), "Rejected");

      // After successful update, refresh the page
      window.location.reload();
    } catch (error) {
      console.log("Error rejecting leave:", error);
    }
  };

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div
        style={{
          marginLeft: "300px",
          marginTop: "70px",
          marginRight: "20px",
        }}
      >
        <h3>Pending Leaves</h3>
        <Table striped bordered hover>
          <thead>
            <tr>
              <th>Employee Name</th>
              <th>Start Date</th>
              <th>End Date</th>
              <th>Reason</th>
              <th>Status</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            {leaves.length > 0 ? (
              leaves.map((leave) => (
                <tr key={leave.leaveId}>
                  <td>
                    {leave.employee.firstName} {leave.employee.lastName}
                  </td>
                  <td>{leave.startDate}</td>
                  <td>{leave.endDate}</td>
                  <td>{leave.reason}</td>
                  <td>{leave.status}</td>
                  <td>
                    {leave.status === "Pending" && (
                      <>
                        <Button
                          variant="success"
                          onClick={() => handleApprove(leave.leaveId)}
                        >
                          Approve
                        </Button>{" "}
                        <Button
                          variant="danger"
                          onClick={() => handleReject(leave.leaveId)}
                        >
                          Reject
                        </Button>
                      </>
                    )}
                  </td>
                </tr>
              ))
            ) : (
              <tr>
                <td colSpan="6" className="no-data-message text-center">
                  No data available of Pending leaves
                </td>
              </tr>
            )}
          </tbody>
        </Table>

        <div className="roster-calendar-go-back-button">
          <NavLink exact to="/Dashboard">
            <button className="btn btn-primary">Go Back</button>
          </NavLink>
        </div>
      </div>
    </>
  );
};

export default LeaveTable;
