import React, { useEffect, useState } from "react";
import { Button, Form, NavLink } from "react-bootstrap";
import { applyLeave } from "../../Service/LeaveApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import "./LeaveForm.css";
import { getAllLeaveCategories } from "../../Service/LeaveCategoryApiService";
import { getEmployeeById } from "../../Service/EmployeeApiService";
import { getAllPublicHolidays } from "../../Service/PublicHolidayApiService";
import { useNavigate } from "react-router-dom";

const LeaveForm = () => {
  const employeeId = sessionStorage.getItem("employeeId");
  const [leaveCategories, setLeaveCategories] = useState([]);
  const [employee, setEmployee] = useState([]);
  const [leave, setLeave] = useState({
    employeeId: employeeId,
    startDate: "",
    endDate: "",
    leaveCategory: "",
    reason: "",
    status: "Pending",
  });
  const [publicHolidays, setPublicHolidays] = useState([]);
  const [errorMessage, setErrorMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");

  useEffect(() => {
    fetchLeaveCategories();
    fetchPublicHolidays();
  }, []);

  const fetchLeaveCategories = async () => {
    try {
      const response = await getAllLeaveCategories();
      setLeaveCategories(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  const fetchPublicHolidays = async () => {
    try {
      const response = await getAllPublicHolidays();
      setPublicHolidays(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    getEmployeeDetails();
  }, []);

  async function getEmployeeDetails() {
    try {
      const response = await getEmployeeById(employeeId);
      setEmployee(response.data);
    } catch (error) {
      console.log(error);
    }
  }

  const handleChange = (event) => {
    const { name, value } = event.target;

    // Check if the selected date falls on a weekend
    if (name === "startDate" || name === "endDate") {
      const selectedDate = new Date(value);
      const day = selectedDate.getDay();

      if (day === 0 || day === 6) {
        return; // Do not update state for weekends
      }
    }

    setLeave((prevLeave) => ({ ...prevLeave, [name]: value }));
  };

  const navigate = useNavigate();
  const handleGoBack = () => {
    navigate("/Dashboard");
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    // Check if the selected dates are public holidays
    const selectedDates = getDatesArray(leave.startDate, leave.endDate);
    const selectedPublicHolidays = publicHolidays.filter((holiday) =>
      selectedDates.includes(holiday.holidayDate)
    );

    if (selectedPublicHolidays.length > 0) {
      const holidayNames = selectedPublicHolidays
        .map((holiday) => holiday.holidayName)
        .join(", ");
      setErrorMessage(
        `The following dates are public holidays: ${holidayNames}. 
        Please choose different dates.`
      );
      setTimeout(() => {
        setErrorMessage(""); // Remove error message after 3 seconds
      }, 3000);
      return;
    }

    try {
      const response = await applyLeave(leave);
      // Handle successful leave application
      console.log(response);
      setSuccessMessage("Leave applied successfully!");

      // Reset the form fields
      setLeave({
        startDate: "",
        endDate: "",
        leaveCategory: "",
        reason: "",
        status: "Pending",
      });

      setTimeout(() => {
        setSuccessMessage(""); // Remove success message after 3 seconds
      }, 3000);
    } catch (error) {
      console.error(error);
      // Handle leave application error or display an error message
    }
  };

  const currentDate = new Date().toISOString().split("T")[0];

  // Helper function to get an array of dates between two dates
  const getDatesArray = (startDate, endDate) => {
    const dates = [];
    const start = new Date(startDate);
    const end = new Date(endDate);
    const current = new Date(start);

    while (current <= end) {
      dates.push(new Date(current).toISOString().split("T")[0]);
      current.setDate(current.getDate() + 1);
    }

    return dates;
  };

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div className="leave-form-page">
        <div className="leave-form-container">
          <div className="leave-form-wrapper">
            <h4
              style={{
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "2em",
              }}
            >
              Apply Leave
            </h4>
            <br />
            <Form onSubmit={handleSubmit}>
              <Form.Group>
                <div className="leave-form-row">
                  <div className="leave-form-column">
                    <Form.Group>
                      <Form.Label className="font-weight-bold">
                        Start Date:<span className="required">*</span>
                      </Form.Label>
                      <Form.Control
                        type="date"
                        name="startDate"
                        value={leave.startDate}
                        onChange={handleChange}
                        required
                      />
                    </Form.Group>
                  </div>
                  <div className="leave-form-column">
                    <Form.Group>
                      <Form.Label className="font-weight-bold">
                        End Date:<span className="required">*</span>
                      </Form.Label>
                      <Form.Control
                        type="date"
                        name="endDate"
                        value={leave.endDate}
                        onChange={handleChange}
                        min={leave.startDate}
                        required
                      />
                    </Form.Group>
                  </div>
                </div>
                <Form.Group>
                  <Form.Label className="font-weight-bold">
                    Leave Category:<span className="required">*</span>
                  </Form.Label>
                  <Form.Control
                    as="select"
                    name="leaveCategory"
                    value={leave.leaveCategory}
                    onChange={handleChange}
                    required
                  >
                    <option value="">Select Leave Category</option>
                    {leaveCategories &&
                      leaveCategories.map((leaveCategory) => {
                        if (
                          employee &&
                          employee.gender === "Male" &&
                          leaveCategory.leaveCategoryName === "Maternity Leave"
                        ) {
                          return null; // Exclude Maternity Leave for male employees
                        }
                        if (
                          employee &&
                          employee.gender === "Female" &&
                          leaveCategory.leaveCategoryName === "Paternity Leave"
                        ) {
                          return null; // Exclude Paternity Leave for female employees
                        }
                        return (
                          <option
                            key={leaveCategory.leaveCategoryId}
                            value={leaveCategory.leaveCategoryId}
                          >
                            {leaveCategory.leaveCategoryName}
                          </option>
                        );
                      })}
                  </Form.Control>
                </Form.Group>
                <Form.Group>
                  <br />
                  <Form.Label className="font-weight-bold">
                    Reason:<span className="required">*</span>
                  </Form.Label>
                  <Form.Control
                    as="textarea"
                    name="reason"
                    value={leave.reason}
                    onChange={handleChange}
                    required
                    className="reason-textarea"
                    rows={5}
                  />
                </Form.Group>
                <br />
                <Button type="submit">Submit</Button>
                <div className="leaveform-go-back-button">
                  <NavLink exact to="/Dashboard">
                    <Button onClick={handleGoBack} className="btn-secondary">
                      Go Back
                    </Button>
                  </NavLink>
                </div>
              </Form.Group>
            </Form>
          </div>
        </div>
        {errorMessage && <div className="error-message">{errorMessage}</div>}
        {successMessage && (
          <div className="success-message">{successMessage}</div>
        )}
      </div>
    </>
  );
};

export default LeaveForm;
