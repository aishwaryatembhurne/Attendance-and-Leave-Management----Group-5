import React, { useEffect, useState } from "react";
import { Card, Button } from "react-bootstrap";
import { BsCheckCircle, BsClock, BsXCircle } from "react-icons/bs";
import {
  getAllLeavesByEmployeeId,
  deleteLeave,
} from "../../Service/LeaveApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import "./LeaveCard.css";
import { NavLink } from "react-router-dom";

export default function LeaveCard() {
  const [leaves, setLeaves] = useState([]);
  const employeeId = sessionStorage.getItem("employeeId");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAllLeavesByEmployeeId(employeeId);
        setLeaves(data.data);
      } catch (error) {
        console.log("Error: ", error);
        // Handle the error or display an error message
      }
    };

    fetchData();
  }, []);

  const handleWithdrawLeave = async (leaveId) => {
    try {
      await deleteLeave(leaveId);
      setLeaves((prevLeaves) =>
        prevLeaves.filter((leave) => leave.leaveId !== leaveId)
      );
      // Display a success message or perform any additional actions
    } catch (error) {
      console.log("Error: ", error);
      // Handle the error or display an error message
    }
  };

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>

      <div className="leave-card-list">
        {leaves.length === 0 ? (
          <div className="no-data-message">No Data of leaves</div>
        ) : (
          leaves.map((leave) => (
            <Card key={leave.leaveId} className="leave-card">
              <Card.Body>
                <div className="leave-card-header">
                  <Card.Title className="leave-type">
                    {leave.leaveCategory &&
                      leave.leaveCategory.leaveCategoryName}
                  </Card.Title>
                  <Card.Text
                    className={`leave-status ${leave.status.toLowerCase()}`}
                  >
                    {leave.status === "Approved" ? (
                      <BsCheckCircle className="leave-status-icon" />
                    ) : leave.status === "Pending" ? (
                      <BsClock className="leave-status-icon" />
                    ) : leave.status === "Rejected" ? (
                      <BsXCircle className="leave-status-icon" />
                    ) : null}
                    {leave.status}
                  </Card.Text>
                </div>
                <Card.Text className="leave-card-date">
                  Dates: {leave.startDate} to {leave.endDate}
                </Card.Text>
                <Card.Text className="leave-card-reason">
                  Reason: {leave.reason}
                </Card.Text>
                {leave.status === "Pending" && (
                  <Button
                    variant="danger"
                    className="leave-withdraw-button"
                    onClick={() => handleWithdrawLeave(leave.leaveId)}
                  >
                    Withdraw
                  </Button>
                )}
              </Card.Body>
            </Card>
          ))
        )}
      </div>
      <div className="leaves-history-go-back-button">
        <NavLink exact to="/Dashboard">
          <button className="btn btn-primary">Go Back</button>
        </NavLink>
      </div>
    </>
  );
}
