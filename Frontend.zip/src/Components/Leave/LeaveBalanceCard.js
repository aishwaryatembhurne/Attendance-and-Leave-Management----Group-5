import React, { useEffect, useState } from "react";
import { getLeaveBalancesByEmployeeId } from "../../Service/LeaveBalanceApiService";
import "./LeaveBalanceCard.css";

const LeaveBalanceCard = () => {
  const [leaveBalances, setLeaveBalances] = useState([]);

  const employeeId = sessionStorage.getItem("employeeId");
  useEffect(() => {
    const fetchLeaveBalances = async () => {
      try {
        // Call the API method to get the leave balances for the employee
        const response = await getLeaveBalancesByEmployeeId(employeeId);
        setLeaveBalances(response.data);
      } catch (error) {
        console.error("Failed to fetch leave balances", error);
      }
    };

    fetchLeaveBalances();
  }, [employeeId]);

  return (
    <div className="card leave-balance-card">
      <div className="card-header">
        <h5 className="card-title">Leave Balances</h5>
      </div>
      <div className="card-body">
        <ul className="list-group">
          {leaveBalances.map((balance) => (
            <li className="list-group-item" key={balance.leaveTypeId}>
              <span className="leave-type">
                {balance.leaveCategory.leaveCategoryName}
              </span>
              <span className="leave-balance">{balance.balance}</span>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

export default LeaveBalanceCard;
