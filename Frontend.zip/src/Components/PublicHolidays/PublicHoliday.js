import React, { useEffect, useState } from "react";
import { getAllPublicHolidays } from "../../Service/PublicHolidayApiService";
import Calendar from "../PublicHolidays/Calendar";

const PublicHolidayPage = () => {
  const [holidays, setHolidays] = useState([]);

  useEffect(() => {
    fetchPublicHolidays();
  }, []);

  const fetchPublicHolidays = async () => {
    try {
      const response = await getAllPublicHolidays();
      setHolidays(response.data);
    } catch (error) {
      console.error("Error fetching public holidays:", error);
    }
  };

  return (
    <div>
      <Calendar holidays={holidays} />
    </div>
  );
};

export default PublicHolidayPage;
