import React, { useState, useEffect } from "react";
import styled, { css } from "styled-components";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import { Container, Row, Col, Button } from "react-bootstrap";
import {
  getAllPublicHolidays,
  // Other API methods if needed
} from "../../Service/PublicHolidayApiService";
import { NavLink } from "react-router-dom";

const Frame = styled.div`
  width: 1137px;
  height: 584px;
  margin-top: 80px;
  margin-left: 320px;
`;

const Header = styled.div`
  display: flex;
  align-items: center;
  justify-content: space-between;
  background-color: #04526b;
  padding: 10px;
  border-radius: 5px;
  font-family: "Raleway", sans-serif;
  h2 {
    color: white;
    margin: 0;
    margin-left: 360px;
  }

  .month {
    margin-left: 250px;
    font-weight: bold;
    font-size: 25px;
  }
`;

const Body = styled.div`
  height: 400px;
  display: flex;
  flex-wrap: wrap;
  border-radius: 10px;
  font-family: "Raleway", sans-serif; /* Update font family */
`;

const Day = styled.div`
  width: 162px;
  height: 75px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  flex-direction: column;
  border: 1px solid #eee;
  background-color: #ffd9ed;
  border-radius: 5px;
  border-color: black;
  font-family: "Raleway", sans-serif; /* Update font family */

  &.today {
    border: 1px solid #eee;
  }

  &.selected {
    background-color: #fff2ed;
  }

  .holiday-name {
    background-color: skyblue;
    border-radius: 5px;
    text-align: left; // Add this line to align the holiday text to the left
  }

  // &.holiday {
  //   background-color: darkgrey; // Set background color to red for holidays
  // }
`;

export function Calendar() {
  const DAYS = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const DAYS_LEAP = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const DAYS_OF_THE_WEEK = ["MON", "TUE", "WED", "THU", "FRI", "SAT", "SUN"];
  const MONTHS = [
    "JAN",
    "FEB",
    "MAR",
    "APR",
    "MAY",
    "JUN",
    "JUL",
    "AUG",
    "SEP",
    "OCT",
    "NOV",
    "DEC",
  ];

  const today = new Date();
  const [date, setDate] = useState(today);
  const [day, setDay] = useState(date.getDate());
  const [month, setMonth] = useState(date.getMonth());
  const [year, setYear] = useState(date.getFullYear());
  const [startDay, setStartDay] = useState(getStartDayOfMonth(date));
  const [holidays, setHolidays] = useState([]);

  useEffect(() => {
    setDay(date.getDate());
    setMonth(date.getMonth());
    setYear(date.getFullYear());
    setStartDay(getStartDayOfMonth(date));

    getAllPublicHolidays()
      .then((response) => {
        const holidaysData = response.data || [];
        console.log("Fetched holidays:", holidaysData);
        setHolidays(holidaysData);
      })
      .catch((error) => {
        console.log("Error fetching holidays:", error);
      });
  }, [date]);

  function getStartDayOfMonth(date) {
    const startDate = new Date(date.getFullYear(), date.getMonth(), 1).getDay();
    return startDate === 0 ? 7 : startDate;
  }

  function isLeapYear(year) {
    return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
  }

  const days = isLeapYear(year) ? DAYS_LEAP : DAYS;

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <Frame>
        <div
          className="holiday-calendar-go-back-button "
          style={{ marginLeft: "1036px", marginBottom: "5px" }}
        >
          <NavLink exact to="/Dashboard">
            <button
              className="btn"
              style={{
                backgroundColor: "#04526b",
                color: "white",
                width: "100px",
              }}
            >
              Go Back
            </button>
          </NavLink>
        </div>
        <Header>
          <Button
            variant="outline-primary" // Updated variant
            onClick={() => setDate(new Date(year, month - 1, day))}
            style={{
              color: "white",
              borderColor: "white",
            }}
          >
            Prev
          </Button>
          <h2>Holiday Calendar</h2>
          <div className="month" style={{ color: "white" }}>
            {MONTHS[month]} {year}
          </div>
          <Button
            variant="outline-primary"
            onClick={() => setDate(new Date(year, month + 1, day))}
            style={{
              color: "white",
              borderColor: "white",
            }}
          >
            Next
          </Button>
        </Header>
        <Body>
          {DAYS_OF_THE_WEEK.map((d) => (
            <Day key={d}>
              <strong>{d}</strong>
            </Day>
          ))}
          {Array(days[month] + (startDay - 1))
            .fill(null)
            .map((_, index) => {
              const d = index - (startDay - 2);

              // Find the holiday for the current date
              const holiday = holidays.find(
                (h) =>
                  new Date(h.holidayDate).getDate() === d &&
                  new Date(h.holidayDate).getMonth() === month &&
                  new Date(h.holidayDate).getFullYear() === year
              );

              return (
                <Day
                  key={index}
                  isToday={d === today.getDate()}
                  isSelected={d === day}
                  onClick={() => setDate(new Date(year, month, d))}
                  className={holiday ? "holiday" : ""}
                >
                  {d > 0 ? d : ""}
                  {holiday && (
                    <span className="holiday-name">{holiday.holidayName}</span>
                  )}
                </Day>
              );
            })}
        </Body>
      </Frame>
    </>
  );
}

export default Calendar;
