import React, { useState, useRef } from "react";
import { Button, NavLink } from "react-bootstrap";
import "./HolidayForm.css";
import {
  createPublicHoliday,
  uploadFile,
  downloadFile,
} from "../../Service/PublicHolidayApiService";
import NavigationBar from "../NavigationBar";
import Sidebar from "../Sidebar";
import { useNavigate } from "react-router-dom";

const HolidayForm = () => {
  const [holiday, setHoliday] = useState({
    holidayDate: "",
    holidayName: "",
  });

  const [errors, setErrors] = useState({
    holidayDate: "",
    holidayName: "",
  });

  const [successMessage, setSuccessMessage] = useState("");

  const fileInputRef = useRef(null);

  const handleChange = (event) => {
    const { name, value } = event.target;

    // Perform validation for Holiday Name field
    if (name === "holidayName" && !/^[a-zA-Z\s]*$/.test(value)) {
      setErrors((prevErrors) => ({
        ...prevErrors,
        holidayName: "Holiday Name should only contain letters",
      }));
      setTimeout(() => {
        setErrors((prevErrors) => ({
          ...prevErrors,
          holidayName: "",
        }));
      }, 3000);
    } else {
      setErrors((prevErrors) => ({ ...prevErrors, [name]: "" }));
      setHoliday((prevHoliday) => ({ ...prevHoliday, [name]: value }));
    }
  };

  const validateForm = () => {
    let isValid = true;
    const newErrors = { ...errors };

    if (!holiday.holidayDate) {
      newErrors.holidayDate = "Holiday Date is required";
      isValid = false;
    } else {
      newErrors.holidayDate = "";
    }

    if (!holiday.holidayName) {
      newErrors.holidayName = "Holiday Name is required";
      isValid = false;
    } else if (typeof holiday.holidayName !== "string") {
      newErrors.holidayName = "Holiday Name should only contain letters.";
      isValid = false;
    } else {
      newErrors.holidayName = "";
    }

    setErrors(newErrors);

    if (!isValid) {
      setTimeout(() => {
        setErrors((prevErrors) => ({
          ...prevErrors,
          holidayDate: "",
          holidayName: "",
        }));
      }, 3000);
    }

    return isValid;
  };

  const handleSubmit = (event) => {
    event.preventDefault();

    if (validateForm()) {
      createPublicHoliday(holiday)
        .then((response) => {
          setSuccessMessage("Holiday added successfully!");
          console.log(response);
          setHoliday({
            holidayDate: "",
            holidayName: "",
          });

          setTimeout(() => {
            setSuccessMessage(""); // Remove success message after 3 seconds
          }, 3000);
        })
        .catch((error) => {
          console.error(error.message);
        });
    } else {
      console.error("No file selected.");
    }
  };

  const navigate = useNavigate();
  const handleGoBack = () => {
    navigate("/Dashboard");
  };

  const handleUpload = (event) => {
    const file = event.target.files[0];

    if (file) {
      uploadFile(file)
        .then((response) => {
          setSuccessMessage("File uploaded successfully!");
          console.log(response);

          setTimeout(() => {
            setSuccessMessage(""); // Remove success message after 3 seconds
          }, 3000);
        })
        .catch((error) => {
          console.error(error.message);
        });
    } else {
      console.error("No file selected.");
    }
  };

  const handleDownload = () => {
    downloadFile()
      .then((response) => {
        const url = window.URL.createObjectURL(new Blob([response.data]));
        const link = document.createElement("a");
        link.href = url;
        link.setAttribute("download", "holidays.xlsx");
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
      })
      .catch((error) => {
        console.error(error.message);
      });
  };

  return (
    <>
      <div className="fixed-top">
        <NavigationBar />
        <Sidebar />
      </div>
      <div
        className="add-holiday-page"
        style={{ marginLeft: "250px", marginTop: "60px" }}
      >
        <div className="add-holiday-container">
          <div className="add-holiday-form">
            <h4
              style={{
                fontWeight: "bold",
                textAlign: "center",
                fontSize: "2em",
              }}
            >
              Holiday Form
            </h4>
            <br />

            <form onSubmit={handleSubmit} noValidate>
              <div className="form-group">
                <label>
                  Holiday Date: <span className="required">*</span>
                </label>
                <input
                  type="date"
                  name="holidayDate"
                  className="form-control"
                  value={holiday.holidayDate}
                  onChange={handleChange}
                  required
                />
                {errors.holidayDate && (
                  <div className="holidayform-error-message">
                    {errors.holidayDate}
                  </div>
                )}
              </div>

              <div className="form-group">
                <label>
                  Holiday Name: <span className="required">*</span>
                </label>
                <input
                  type="text"
                  name="holidayName"
                  className="form-control"
                  value={holiday.holidayName}
                  onChange={handleChange}
                  required
                />
                {errors.holidayName && (
                  <div className="holidayform-error-message">
                    {errors.holidayName}
                  </div>
                )}
              </div>

              <Button type="submit" className="btn-primary">
                Add Holiday
              </Button>

              <input
                type="file"
                accept=".xlsx, .xls"
                style={{ display: "none" }}
                onChange={handleUpload}
                ref={fileInputRef}
              />
              <Button
                className="btn-secondary"
                onClick={() => fileInputRef.current.click()}
              >
                Upload
              </Button>

              <Button onClick={handleDownload} className="btn-secondary">
                Download
              </Button>

              <NavLink exact to="/Dashboard">
                <Button onClick={handleGoBack} className="btn-secondary">
                  Go Back
                </Button>
              </NavLink>
            </form>

            {successMessage && (
              <div className="holidayform-success-message">
                {successMessage}
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
};

export default HolidayForm;
