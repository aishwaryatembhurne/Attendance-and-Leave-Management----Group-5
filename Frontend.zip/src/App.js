import React from "react";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Dashboard from "./Pages/Dashboard";
import LoginPage from "./Pages/Login";
import LeaveCard from "./Components/Leave/LeaveCard";
import EmployeeDetails from "./Components/Employee/EmployeeDetails";
import AddEmployee from "./Components/Employee/EmployeeForm";
import LeaveTable from "./Components/Leave/PendingLeaves";
import PublicHolidayPage from "./Components/PublicHolidays/PublicHoliday";
import RosterPage from "./Components/Roster/Roster";
import EmployeeAttendanceTable from "./Components/Employee/EmployeeAttendance/EmployeeAttendance";
import AttendanceHistory from "./Components/Attendance History/AttendanceHistory";
import EmployeeLeaveCard from "./Components/Employee/EmployeeLeaveCard";
import EmployeeDetailsPage from "./Components/Employee/EmployeeProfile";
import HolidayForm from "./Components/PublicHolidays/HolidayForm";
import LeaveForm from "./Components/Leave/LeaveForm";
import AddRoster from "./Components/Roster/RosterForm";
import EditEmployee from "./Components/Employee/EditEmployee/EditEmployee";
import AllEmployees from "./Components/Employee/AllEmployees/AllEmployees";

function App() {
  return (
    <div>
      <BrowserRouter>
        <Routes>
          <Route exact path="/Dashboard" element={<Dashboard />} />
          <Route exact path="/" element={<LoginPage />} />
          <Route exact path="/leave-history" element={<LeaveCard />} />
          <Route
            exact
            path="/employee-list"
            element={<EmployeeDetails />}
          ></Route>
          <Route exact path="/add-employee" element={<AddEmployee />}></Route>
          <Route exact path="/pending-leaves" element={<LeaveTable />}></Route>
          <Route
            exact
            path="/holiday-calendar"
            element={<PublicHolidayPage />}
          ></Route>
          <Route exact path="/roster-calendar" element={<RosterPage />}></Route>
          <Route
            exact
            path="/AdminDashboard/Employee/Attendance/:employeeId"
            element={<EmployeeAttendanceTable />}
          />
          <Route
            exact
            path="/attendance-history"
            element={<AttendanceHistory />}
          />
          <Route
            exact
            path="/employee-leaves/:employeeId"
            element={<EmployeeLeaveCard />}
          ></Route>
          <Route
            exact
            path="/employee-profile"
            element={<EmployeeDetailsPage />}
          ></Route>
          <Route exact path="/add-holiday" element={<HolidayForm />}></Route>
          <Route exact path="/add-roster" element={<AddRoster />}></Route>
          <Route exact path="/add-employee" element={<AddEmployee />}></Route>
          <Route exact path="/apply-leave" element={<LeaveForm />}></Route>
          <Route path="/edit-employee/:id" element={<EditEmployee />} />
          <Route path="/all-employees" element={<AllEmployees />} />
          <Route
            exact
            path="/AdminDashboard/Employee/Edit/:employeeId"
            element={<EditEmployee />}
          ></Route>
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
