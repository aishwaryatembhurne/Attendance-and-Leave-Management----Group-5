package com.als.user;

public enum Role {
USER,ADMIN,MANAGER,HR
}
